import polars as pl
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("TestHFT3")

files = sorted(list(Path("results").glob("b*.parquet")))
if files:
    f = files[0]
    df = pl.read_parquet(f)
    print("Columns available:", df.columns)
    
    local_aggs = [
        pl.len().alias("count_map"),
        pl.col("amount").abs().sum().alias("vol_sum_map"),
        (pl.col("amount")**2).sum().alias("vol_sq_sum_map"), # For StdDev
        pl.col("amount").abs().max().alias("amt_max_map"),
        pl.col("amount").abs().min().alias("amt_min_map"),
        pl.col("transaction_timestamp").min().alias("ts_min_map"),
        pl.col("transaction_timestamp").max().alias("ts_max_map"),
        
        # Channel Specific Maps
        *[pl.col("amount").filter(pl.col("channel") == c).abs().sum().alias(f"vol_{c.lower()}_map") for c in ["UPI", "ATM", "CASH", "IMPS", "NEFT", "RTGS"]],
        *[pl.col("amount").filter(pl.col("channel") == c).len().alias(f"cnt_{c.lower()}_map") for c in ["UPI", "ATM", "CASH", "IMPS", "NEFT", "RTGS"]],
        
        # Type Specific Maps
        pl.col("amount").filter(pl.col("txn_type") == "C").abs().sum().alias("c_vol_map"),
        pl.col("amount").filter(pl.col("txn_type") == "D").abs().sum().alias("d_vol_map"),
        pl.col("amount").filter(pl.col("txn_type") == "C").len().alias("c_cnt_map"),
        pl.col("amount").filter(pl.col("txn_type") == "D").len().alias("d_cnt_map"),
        
        # Interaction Probes
        pl.col("counterparty_id").n_unique().alias("cp_uniq_map"),
        pl.col("ip_address").n_unique().alias("ip_uniq_map"),
        
        # Forensic Pattern Maps
        pl.col("amount").abs().filter(pl.col("amount").abs() % 1000 == 0).len().alias("round_cnt_map"),
        pl.col("amount").abs().filter((pl.col("amount").abs() > 48000) & (pl.col("amount").abs() < 50000)).len().alias("struc_cnt_map"),
        
        # Propagate Master values
        pl.col("avg_daily_balance").first().alias("avg_bal_map"),
        pl.col("kyc_status").first().alias("kyc_map"),
        pl.col("branch_lat").first().alias("branch_lat_map"),
        pl.col("branch_lon").first().alias("branch_lon_map"),
        
        # Geospatial Anchors
        pl.col("latitude").last().alias("last_lat_map"),
        pl.col("longitude").last().alias("last_lon_map"),
    ]
    
    try:
        res = df.group_by("account_id").agg(local_aggs)
        print("Success!")
    except Exception as e:
        import traceback
        traceback.print_exc()
