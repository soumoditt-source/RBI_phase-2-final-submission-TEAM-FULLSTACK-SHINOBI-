import zipfile
import os

print('🚀 Packing Code Submission using OS.Walk (Fast Mode)')

OUTPUT_DIR = r"d:\RBI NFPC PHASE 2\app\FULLSTACK__SHINOBI_NFPC_RBIH_PHASE_2"
OUTPUT_ZIP = os.path.join(OUTPUT_DIR, 'FullStackShinobi_rbi_nfpc_phase2_Code.zip')

ALLOWED = {'.py','.ipynb','.sh','.bat','.json','.yaml','.yml','.toml','.cfg','.ini','.txt','.md','.pkl','.joblib','.pt','.pth','.onnx','.h5'}
SKIP_DATA = {'.parquet','.csv','.hdf5','.npy','.npz','.feather'}
# PRUNING THESE DIRECTORIES STOPS INFINITE SCANNING
SKIP_DIRS = {'.venv', '__pycache__', '.git', 'transactions', 'transactions_additional', 'tmp_shards', '.snapshots', '.vscode', 'final_submission_bundle', 'results', 'app\\FULLSTACK__SHINOBI_NFPC_RBIH_PHASE_2'}

added = 0
with zipfile.ZipFile(OUTPUT_ZIP, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('.'):
        # Prune dirs in-place to avoid descending into .venv or heavy data dirs!
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith('.')]
        
        for name in files:
            path = os.path.join(root, name)
            rel_path = os.path.relpath(path, '.')
            
            ext = os.path.splitext(name)[1].lower()
            
            # Skip heavy data
            if ext in SKIP_DATA: continue
            
            # Skip logs
            if name.endswith('.log'): continue
            
            # Skip the output dir zip files if any exist here
            if '.zip' in name: continue
            
            # Enforce allowed extensions
            if ext and ext not in ALLOWED: continue
            
            # Write file
            zf.write(path, rel_path)
            added += 1

size_mb = os.path.getsize(OUTPUT_ZIP) / (1024 * 1024)
print(f'✅ CREATED {OUTPUT_ZIP}')
print(f'   Files Zipped = {added}')
print(f'   Total Size   = {size_mb:.2f} MB')

# Copy the CSV to output directly
import shutil
csv_out = os.path.join(OUTPUT_DIR, 'FullStackShinobi_rbi_nfpc_phase2_Predictions.csv')
shutil.copy2('submission.csv', csv_out)
print(f'✅ COPIED CSV -> {csv_out}')

report_md = "FullStackShinobi_rbi_nfpc_phase2_Judges_Report.md"
tech_md = "FullStackShinobi_rbi_nfpc_phase2_Tech_Arch.md"
if os.path.exists(report_md): shutil.copy2(report_md, OUTPUT_DIR)
if os.path.exists(tech_md): shutil.copy2(tech_md, OUTPUT_DIR)
print('✅ COPIED REPORTS')
