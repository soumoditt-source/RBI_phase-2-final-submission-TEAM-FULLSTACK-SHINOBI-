# Ultimate Architecture Log: FullStackShinobi

## What We Have Built So Far

1. **8-Tab Supreme Dashboard**: Built a Streamlit UI handling PyDeck 3D Geographic visualization (with 2000 geo-routes) and a massive Money Network Sankey diagram. Resolved JSON dictionary key errors.
2. **Polars Ingestion Pipeline**: Created `src/data/pipeline.py` to process the multi-part transactions using `polars.scan_parquet()`.
3. **13 Mule Anomalies EDA**: Extracted 13 distinct fraud patterns (structuring, fan-in/fan-out, dormancy, MCC anomalies) mapped to formal PMLA/FATF regulations.
4. **Model Explainability & Legal Engine**: Built SHAP value extractors, a 10-rule legal compliance engine that drops PMLA statutes based on feature quantiles.
5. **Temporal & Geo Burst Detectors**: Isolated exact timestamps where accounts switch to mule behavior. Mapped origin coordinates to destination coordinates.

## Flaw Analysis (Dead-Honest Judge Review)

- **The "5%" Problem**: The user noticed the current cache feels too small for 16GB. When we `scan_parquet().collect()`, if we use `--sample 0.05` or limit the rows due to memory, we are truncating the dataset.
- **Memory Crash Vulnerability on 16GB RAM**: A 16.2GB dataset cannot be entirely `.collect()`ed into 16GB RAM. Polars streaming is good, but joins explode RAM. We must use a true piece-by-piece **Chunk Theory Approach**.
- **Feature Depth**: Phase 1 had 48+ features. Phase 2 currently aggregates ~20-30 features. We need advanced HFT (High Frequency Trading) level features: EMA (Exponential Moving Averages), Velocity spikes down to the millisecond, Multi-hop centrality approximations, VWAP (Volume-Weighted Average Price per transaction), and Inter-arrival Time Variances.

## The Action Plan (HFT Chunk Theory)

1. **Chunk-by-Chunk Processing System**: Rewrite the ingestion engine to literally stream through the 6 parquet files one-by-one (or in strict batches), aggregating at the account level *incrementally*, and saving partial state. This mathematically guarantees 100% data processing with `<4GB` RAM usage.
2. **50+ Feature Expansion**: Enhance `pipeline.py` to extract 50+ hyper-advanced forensic features per account.
3. **Absolute 100% Coverage**: The final `final_features.parquet` will represent 100% of the 7.4 million transactions and all 64,062 accounts securely.
