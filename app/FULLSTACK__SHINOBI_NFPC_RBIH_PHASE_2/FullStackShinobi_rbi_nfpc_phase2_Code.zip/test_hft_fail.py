import polars as pl
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("TestHFT")

files = sorted(list(Path("results").glob("b*.parquet")))
log.info(f"Found {len(files)} files")

if files:
    f = files[0]
    log.info(f"Checking {f}")
    df = pl.read_parquet(f)
    log.info(f"Columns: {df.columns}")
    log.info(f"Shape: {df.shape}")
    
    # Try the group_by
    local_aggs = [
        pl.len().alias("count_map"),
        pl.col("amount").abs().sum().alias("vol_sum_map"),
        pl.col("transaction_timestamp").min().alias("ts_min_map"),
        pl.col("txn_type").filter(pl.col("txn_type") == "C").len().alias("c_cnt_map"),
    ]
    try:
        df_part = df.group_by("account_id").agg(local_aggs)
        log.info(f"Aggigated shape: {df_part.shape}")
    except Exception as e:
        log.error(f"Aggregation failed: {e}")
