import os
import subprocess
import sys
import logging
import time
from pathlib import Path

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("NFPC.FinalRun")

DATA_DIR = Path(__file__).parent
SUBMISSION = DATA_DIR / "submission.csv"

def main():
    log.info("🚀 TRIGGERING FINAL 16GB ULTIMATE PIPELINE...")
    log.info("Architecture: Scipy Sparse CSR (OOM-Safe)")
    
    # Removing old submission to force fresh 100% run with new stable architecture
    if SUBMISSION.exists():
        os.remove(SUBMISSION)
    
    # Run the pipeline
    cmd = [sys.executable, "run_all.py", "--sample", "1.0", "--audit", "--explain"]
    log.info(f"Command: {' '.join(cmd)}")
    
    with open("pipeline_final_stable.log", "w") as f:
        process = subprocess.Popen(cmd, stdout=f, stderr=f, cwd=str(DATA_DIR))
        log.info(f"Pipeline started in background (PID: {process.pid})")
        log.info("Monitoring 'pipeline_final_stable.log' for progress...")
    
    # Launch Dashboard
    log.info("🚀 Launching Forensic Dashboard...")
    subprocess.run([sys.executable, "launch.py"], cwd=str(DATA_DIR))

if __name__ == "__main__":
    main()
