import pandas as pd
import numpy as np

print("=============================================")
print(" 🕒 TEMPORAL IOU FORMATTING & OPTIMIZATION   ")
print("=============================================")

df = pd.read_csv("submission.csv")
print(f"Original shape: {df.shape}")

# 1. Clear timestamps for low-probability accounts to boost IoU
threshold = 0.40  # Only keep timestamps for accounts with reasonable suspicion
mask_legit = df['is_mule'] < threshold
df.loc[mask_legit, 'suspicious_start'] = np.nan
df.loc[mask_legit, 'suspicious_end'] = np.nan

# 2. Format dates strictly to YYYY-MM-DDTHH:MM:SS
def format_date(val):
    if pd.isna(val) or str(val).strip() == "":
        return ""
    try:
        # Parse whatever format it currently is
        dt = pd.to_datetime(val)
        # Output exactly with 'T' separator
        return dt.strftime('%Y-%m-%dT%H:%M:%S')
    except:
        return ""

df['suspicious_start'] = df['suspicious_start'].apply(format_date)
df['suspicious_end'] = df['suspicious_end'].apply(format_date)

# 3. Ensure 'T' exists and no NaN strings
df.to_csv("submission.csv", index=False)
print("✅ submission.csv optimized for Temporal IoU scoring.")
print(f"   Dates preserved for {len(df[df['is_mule'] >= threshold])} high-risk accounts.")
print(f"   Sample formatted row:")
print(df[df['is_mule'] >= threshold].head(1).to_dict('records'))
