import os
import zipfile
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("Shinobi.SubCompiler")

def create_submission_zip():
    log.info("=" * 60)
    log.info("📦 FULLSTACK SHINOBI - PHASE 2 SUPREME SUBMISSION COMPILER")
    log.info("=" * 60)

    output_filename = "FULLSTACK_SHINOBI_PHASE_2_SUPREME.zip"
    
    # Files and directories to include (No raw 16GB data)
    includes = [
        "app",
        "src",
        "results", # Contains only the aggregated JSON tabs, no 16GB raw files
        "shinobi_launch.py",
        "build_tab_data.py",
        "build_geo_arcs.py",
        "FINAL_JUDGE_REPORT.md",
        "README_ULTIMATE.md",
        "submission.csv",
        "requirements.txt"
    ]
    
    # Exclude massive intermediates to keep zip clean
    excludes = [
        "__pycache__",
        "hft_features.parquet",
        "final_features",
        "transactions",
        "transactions_additional",
        ".git"
    ]

    cwd = Path(".")
    
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for item in includes:
            item_path = cwd / item
            if not item_path.exists():
                log.warning(f"Missing expected item: {item}. Skipping.")
                continue
                
            if item_path.is_file():
                if item_path.name not in excludes and item_path.suffix != ".parquet":
                    log.info(f"Adding file: {item}")
                    zipf.write(item_path, arcname=item)
            elif item_path.is_dir():
                for root, dirs, files in os.walk(item_path):
                    # Skip excluded directories
                    dirs[:] = [d for d in dirs if d not in excludes and d != "__pycache__"]
                    
                    for file in files:
                        file_path = Path(root) / file
                        
                        # Only include parquet if it's very small or absolutely needed? 
                        # We don't want the giant feature matrices. We only include code + JSONs.
                        if file_path.suffix == ".parquet" and item == "results":
                            continue # Don't pack the heavy feature files
                            
                        if file not in excludes:
                            arcname = file_path.relative_to(cwd)
                            zipf.write(file_path, arcname=str(arcname))
                            
    log.info("=" * 60)
    log.info(f"✅ Submission successfully compiled: {output_filename}")
    size_mb = os.path.getsize(output_filename) / (1024 * 1024)
    log.info(f"   Total Size: {size_mb:.2f} MB")
    log.info("   Ready for upload to RBI Innovation Hub Judging Portal.")

if __name__ == "__main__":
    create_submission_zip()
