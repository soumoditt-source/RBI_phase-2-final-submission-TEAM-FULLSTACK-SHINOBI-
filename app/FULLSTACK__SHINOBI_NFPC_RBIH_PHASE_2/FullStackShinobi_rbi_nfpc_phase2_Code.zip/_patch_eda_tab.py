"""
MuleHunter.AI — Patch 3: Add EDA Showcase Tab to dashboard.py
Adds TAB 0.5 (EDA Results) between Mission Control and Violations Ledger,
showing all 13 mule patterns with counts, evidence, and top account lists.
Run: python _patch_eda_tab.py
"""
from pathlib import Path

DASH = Path("app/dashboard.py")
text  = DASH.read_text(encoding="utf-8")

# ── 1. Update page tabs list to include EDA tab ──────────────────────────────
OLD_TABS = '''tabs = st.tabs([
    "🏠 Mission Control",
    "🚨 Violations Ledger",
    "🕸️ Money Network",
    "⏱️ Temporal Forensics",
    "🗺️ Geo Intelligence",
    "📋 Account Deep-Dive",
    "📊 Model Explainability",
])'''

NEW_TABS = '''tabs = st.tabs([
    "🏠 Mission Control",
    "📊 EDA: 13 Patterns",
    "🚨 Violations Ledger",
    "🕸️ Money Network",
    "⏱️ Temporal Forensics",
    "🗺️ Geo Intelligence",
    "📋 Account Deep-Dive",
    "🤖 Model Explainability",
])'''

text = text.replace(OLD_TABS, NEW_TABS)

# ── 2. Fix tab index references (shift by 1 after inserting EDA tab) ─────────
# tabs[1] -> tabs[2]  (Violations), tabs[2]->tabs[3], etc.
# We do this in reverse order to avoid double-replacing
for old_i, new_i in [(6,7),(5,6),(4,5),(3,4),(2,3),(1,2)]:
    text = text.replace(f"with tabs[{old_i}]:", f"with tabs[{new_i}]:")

# ── 3. Inject EDA tab after "# TAB 1: Mission Control" section ───────────────
EDA_TAB_CODE = '''
# ===============================================================================
# TAB 2 (index 1): EDA Showcase — All 13 Official Mule Patterns
# ===============================================================================
with tabs[1]:
    st.markdown(
        '<div class="section-title">EDA: 13 Official Mule Pattern Analysis</div>'
        '<div class="section-sub">Batch-by-batch analysis across ALL 16.2GB data. '
        'Every pattern from the RBI NFPC README systematically detected and quantified.</div>',
        unsafe_allow_html=True
    )

    @st.cache_data(ttl=600)
    def load_eda_results():
        p = DATA_DIR / "results" / "eda_results.json"
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    eda = load_eda_results()

    PATTERN_COLORS = {
        "Dormant_Activation":       "#ff3366",
        "Structuring":              "#ff3366",
        "Rapid_PassThrough":        "#ff8c42",
        "FanIn_FanOut":             "#ff8c42",
        "Geographic_Anomaly":       "#ffd60a",
        "New_Account_HighValue":    "#ffd60a",
        "Income_Mismatch":          "#00e096",
        "PostMobile_Change_Spike":  "#ff3366",
        "Round_Amount_Patterns":    "#00b4ff",
        "Layered_Subtle":           "#a78bfa",
        "Salary_Cycle_Exploitation":"#00e096",
        "Branch_Level_Collusion":   "#ff8c42",
        "MCC_Amount_Anomaly":       "#a78bfa",
    }

    PATTERN_RULES = {
        "Dormant_Activation":       "FATF-R.20 | RBI KYC MD 2016",
        "Structuring":              "PMLA 2002 Sec 12(1)(a) | PML Rules 2005 Rule 3",
        "Rapid_PassThrough":        "PMLA 2002 Sec 3 | RBI-STR-002",
        "FanIn_FanOut":             "PMLA 2002 Sec 3 | FATF-R.11",
        "Geographic_Anomaly":       "RBI KYC MD 2016 | INT-AML-010",
        "New_Account_HighValue":    "RBI KYC MD 2016 | FATF-R.10",
        "Income_Mismatch":          "FATF-R.10 | RBI EDD Guidelines",
        "PostMobile_Change_Spike":  "RBI KYC MD 2016 Sec 38 | PMLA 2002",
        "Round_Amount_Patterns":    "PMLA 2002 | RBI-STR-002 Structuring",
        "Layered_Subtle":           "FATF-R.11 | Basel AML Index 2024",
        "Salary_Cycle_Exploitation":"PMLA 2002 | FATF ML Typology 2024",
        "Branch_Level_Collusion":   "PMLA 2002 Sec 3 | RBI-BRCH-009",
        "MCC_Amount_Anomaly":       "FATF-R.16 | RBI NEFT/RTGS Guidelines 2019",
    }

    if not eda or "patterns" not in eda:
        st.warning("EDA results not yet generated. Run `shinobi_launch.py` to process all 16.2GB data.")
        st.info("Quick demo run: `python shinobi_launch.py --sample 0.01`")
        # Show the pattern framework even without data
        st.markdown("### Pattern Framework (Pre-loaded from README)")
        ctx1, ctx2, ctx3 = st.columns(3)
        patterns_list = list(PATTERN_COLORS.keys())
        for i, pat in enumerate(patterns_list):
            clr = PATTERN_COLORS[pat]
            [ctx1, ctx2, ctx3][i%3].markdown(f"""
            <div style="border-left:3px solid {clr};padding:8px 12px;margin-bottom:8px;
                        background:rgba(255,255,255,0.02);border-radius:0 6px 6px 0;">
                <div style="font-size:0.75rem;font-weight:700;color:{clr};">{pat.replace('_',' ')}</div>
                <div style="font-size:0.63rem;color:#8b9dc3;">{PATTERN_RULES.get(pat,'')}</div>
            </div>""", unsafe_allow_html=True)
    else:
        # ---- Pattern summary bar chart ----
        patterns_data = eda.get("patterns", {})
        summary = eda.get("summary", {})

        summary_df = pd.DataFrame([
            {"Pattern": k.replace("_"," "), "Signals": v,
             "Color": PATTERN_COLORS.get(k, "#8b9dc3")}
            for k, v in sorted(summary.items(), key=lambda x: -x[1]) if v > 0
        ])

        if not summary_df.empty:
            fig_pat = px.bar(
                summary_df, x="Signals", y="Pattern", orientation="h",
                color="Color", color_discrete_map="identity",
                text="Signals", title="Signal Count by Mule Pattern (All 16GB Data)"
            )
            fig_pat.update_layout(
                template="plotly_dark", paper_bgcolor=BG_CLEAR, plot_bgcolor=BG_PLOT,
                height=500, font_family="Inter", showlegend=False,
                margin={"l": 20, "r": 20, "t": 40, "b": 20},
                title_font_size=13, title_font_color="#8b9dc3",
            )
            st.plotly_chart(fig_pat, use_container_width=True)

        # ---- Per-pattern deep dive cards ----
        st.markdown('<div class="section-title">Pattern Deep-Dive</div>', unsafe_allow_html=True)
        sel_pat = st.selectbox("Select Pattern", list(patterns_data.keys()),
                               format_func=lambda x: x.replace("_"," "))
        pat_detail = patterns_data.get(sel_pat, {})
        clr = PATTERN_COLORS.get(sel_pat, "#8b9dc3")

        pd1, pd2, pd3 = st.columns(3)
        pd1.markdown(f"""
        <div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                    border-radius:10px;padding:14px;text-align:center;">
            <div style="font-size:1.8rem;font-weight:800;color:{clr};">{pat_detail.get('flagged_count',0):,}</div>
            <div style="font-size:0.68rem;color:#8b9dc3;">TOTAL SIGNALS</div>
        </div>""", unsafe_allow_html=True)
        pd2.markdown(f"""
        <div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                    border-radius:10px;padding:14px;text-align:center;">
            <div style="font-size:1.8rem;font-weight:800;color:{clr};">{pat_detail.get('unique_accounts',0):,}</div>
            <div style="font-size:0.68rem;color:#8b9dc3;">UNIQUE ACCOUNTS</div>
        </div>""", unsafe_allow_html=True)
        pd3.markdown(f"""
        <div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                    border-radius:10px;padding:14px;">
            <div style="font-size:0.68rem;color:#8b9dc3;">REGULATORY CITATION</div>
            <div style="font-size:0.75rem;font-weight:700;color:{clr};margin-top:4px;">{PATTERN_RULES.get(sel_pat,'')}</div>
            <div style="font-size:0.68rem;color:#8b9dc3;margin-top:4px;">{pat_detail.get('description','')}</div>
        </div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        # Top accounts
        top_accs = pat_detail.get("top_accounts", [])
        if top_accs:
            st.markdown(f"**Top Accounts with {sel_pat.replace('_',' ')} signal:**")
            accs_df = pd.DataFrame({"Account ID": top_accs})
            st.dataframe(accs_df, use_container_width=True, height=200)

        # Evidence table
        evidence = pat_detail.get("evidence_sample", [])
        if evidence:
            st.markdown("**Forensic Evidence Sample:**")
            ev_df = pd.DataFrame(evidence)
            st.dataframe(ev_df, use_container_width=True)

        # ---- Meta stats ----
        st.markdown("---")
        meta = eda.get("meta", {})
        m1, m2, m3 = st.columns(3)
        m1.metric("Batch Files Processed", f"{meta.get('total_batches_processed', '—'):,}")
        m2.metric("Patterns Checked", len(meta.get("patterns_checked", [])))
        m3.metric("Coverage", f"{meta.get('sample_frac',1)*100:.0f}% of dataset")

'''

# Insert EDA tab right after Mission Control section ends (before TAB 2 which is now TAB 3)
# Find the spot just before "# TAB 2: Violations Ledger" header in the patched code
# (which is now "# TAB 2 (index 1):" because we haven't run the eda patch yet)
insert_marker = "# TAB 2 (index 1): EDA Showcase"
if insert_marker not in text:
    # Find the old marker
    old_marker_variations = [
        "# TAB 2: Violations Ledger -- Supreme Legal Action Intelligence\n# ===",
        "# TAB 2: Violations Ledger",
    ]
    inserted = False
    for om in old_marker_variations:
        idx = text.find(om)
        if idx != -1:
            text = text[:idx] + EDA_TAB_CODE + "\n" + text[idx:]
            inserted = True
            print(f"[OK] EDA tab injected before '{om}'")
            break
    if not inserted:
        print("[WARN] Could not find injection point for EDA tab")
else:
    print("[SKIP] EDA tab already present")

DASH.write_text(text, encoding="utf-8")
print("[DONE] EDA tab patch complete.")
print(f"Dashboard file: {DASH} ({DASH.stat().st_size//1024}KB)")
