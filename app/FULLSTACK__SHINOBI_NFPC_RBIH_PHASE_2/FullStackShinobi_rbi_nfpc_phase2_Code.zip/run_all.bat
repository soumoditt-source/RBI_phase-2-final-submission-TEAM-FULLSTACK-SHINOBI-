@echo off
color 0A
echo =========================================================
echo    RBI NFPC PHASE 2: SUPREME FINAL JUDICIAL AUDIT
echo =========================================================
echo.

TITLE FullStack Shinobi - 17.2GB Data Engine

if not exist ".venv\Scripts\Activate.ps1" goto ErrorNoEnv
goto StartRun

:ErrorNoEnv
echo [ERROR] Virtual Environment (.venv) not found.
echo Please make sure you are in the project root: "d:\RBI NFPC PHASE 2"
pause
exit /b 1

:StartRun
echo [1/3] Activating Virtual Environment...
call .venv\Scripts\activate.bat

echo [2/3] Running Verification Script (Data Coverage & Checks)...
python verify_submission.py
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Verification failed. Please check logs.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo [3/3] Launching Supreme FIU Dashboard (Mission Control)...
echo (Ports 8501-8503 will be cleared to ensure clean boot)
powershell -Command "Get-NetTCPConnection -LocalPort 8501,8502,8503 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"

streamlit run app/dashboard.py --server.port 8501

pause
