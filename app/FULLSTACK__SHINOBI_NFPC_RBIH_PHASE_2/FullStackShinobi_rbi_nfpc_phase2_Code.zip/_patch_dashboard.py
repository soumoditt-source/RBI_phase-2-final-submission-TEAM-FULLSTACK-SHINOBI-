"""
Patch dashboard.py: upgrade TAB 2 (Violations Ledger) and TAB 5 (Geo Intelligence)
with the full README-aligned 13-pattern legal ledger and real 3D globe.
Run: python _patch_dashboard.py
"""
from pathlib import Path

DASH = Path("app/dashboard.py")

# === TAB 2 REPLACEMENT ===
TAB2_MARKER_START = "# TAB 2: Violations Ledger"
TAB2_MARKER_END   = "# TAB 3: Cyber-Security Money Chain"

TAB2_NEW = '''# TAB 2: Violations Ledger -- Supreme Legal Action Intelligence
# ===============================================================================
with tabs[1]:
    # ---- 13 Official Mule Patterns from RBI NFPC README ----
    MULE_PATTERNS = {
        "Dormant Activation":      ("Sudden high-value burst from long-inactive account",          "FATF-R.20"),
        "Structuring":             ("Repeated txns just below INR 10L reporting threshold",        "PMLA 2002 Sec 12(1)(a)"),
        "Rapid Pass-Through":      ("Large credits followed by matching debits within hours",       "RBI-STR-002"),
        "Fan-In / Fan-Out":        ("Many small inflows aggregated into one outflow or vice-versa","RBI-CTR-001"),
        "Geographic Anomaly":      ("Transactions from locations inconsistent with account profile","INT-AML-010"),
        "New Account High Value":  ("Recently opened account with unusually high txn volumes",     "RBI-KYC-003"),
        "Income Mismatch":         ("Txn values disproportionate to balance or customer profile",  "FATF-R.10"),
        "Post-Mobile-Change Spike":("Transaction surge after mobile number update (account takeover)","RBI-KYC-003"),
        "Round Amount Patterns":   ("Excess use of exact round amounts (1K, 5K, 10K, 50K)",       "RBI-STR-002"),
        "Layered/Subtle":          ("Weak signals from multiple patterns combined",                "FATF-R.11"),
        "Salary Cycle Exploitation":("Laundering disguised within salary credits at month boundaries","RBI-CBWT-004"),
        "Branch-Level Collusion":  ("Clusters of suspicious accounts at same branch",             "RBI-BRCH-009"),
        "MCC-Amount Anomaly":      ("Amounts are statistical outliers for their merchant category","RBI-STRX-010"),
    }

    st.markdown(
        '<div class="section-title">Statutory Violations Ledger</div>'
        '<div class="section-sub">Every breach mapped to official Indian (RBI/PMLA/FIU-IND) and '
        'international (FATF/Basel/Wolfsberg) regulations. All 13 known mule patterns covered.</div>',
        unsafe_allow_html=True
    )

    @st.cache_data(ttl=600)
    def load_enriched_violations():
        """Load violations and enrich with demographics + account details."""
        import pandas as pd
        from pathlib import Path
        root = Path(__file__).parent.parent

        # Load reference tables
        def safe_read(fname):
            p = root / fname
            if p.exists():
                try:
                    return pd.read_parquet(p)
                except Exception:
                    return pd.DataFrame()
            return pd.DataFrame()

        accts   = safe_read("accounts.parquet")[["account_id","kyc_compliant","last_kyc_date",
                                                  "account_status","branch_code","branch_pin",
                                                  "product_family","account_opening_date",
                                                  "freeze_date","rural_branch","avg_balance"]]
        demog   = safe_read("demographics.parquet")[["customer_id","name","gender","phone_number",
                                                      "address","nri_flag","joint_account_flag"]]
        linkage = safe_read("customer_account_linkage.parquet")
        addl    = safe_read("accounts-additional.parquet")
        branch  = safe_read("branch.parquet")[["branch_code","branch_city","branch_state","branch_type"]]
        prod    = safe_read("product_details.parquet")[["customer_id","sa_sum","sa_count","loan_count"]]

        pii = pd.DataFrame()
        if not linkage.empty and not demog.empty:
            pii = linkage.merge(demog, on="customer_id", how="left")
            if not prod.empty:
                pii = pii.merge(prod, on="customer_id", how="left")
        if not accts.empty and not pii.empty:
            pii = pii.merge(accts, on="account_id", how="left")
        if not addl.empty and not pii.empty:
            pii = pii.merge(addl, on="account_id", how="left")
        if not branch.empty and not pii.empty and "branch_code" in pii.columns:
            pii = pii.merge(branch, on="branch_code", how="left")

        return pii

    enriched = load_enriched_violations()
    acc_pii: dict = {}
    if not enriched.empty and "account_id" in enriched.columns:
        for _, row in enriched.iterrows():
            acc_pii[row["account_id"]] = row.to_dict()

    viols_df = violations_to_df(violations)

    if viols_df.empty:
        st.info("No violations data yet. Run the pipeline first.")
    else:
        # ---- Filters ----
        f1, f2, f3, f4 = st.columns([2, 1.5, 1, 1])
        with f1:
            search_q = st.text_input("Search Account / Name / Phone / Pattern", "",
                                     placeholder="e.g. ACCT_123, Priya, +91... or Structuring")
        with f2:
            sel_sev = st.multiselect("Severity", ["CRITICAL","HIGH","MEDIUM","LOW"],
                                     default=["CRITICAL","HIGH"])
        with f3:
            sel_rule = st.multiselect("Rule ID", sorted(viols_df[COL_RULE_ID].dropna().unique()),
                                      default=[])
        with f4:
            score_flt = st.slider("Min Risk Score", 0.0, 1.0, 0.40, 0.01)

        df_f = viols_df.copy()
        if sel_sev:
            df_f = df_f[df_f["Severity"].isin(sel_sev)]
        if sel_rule:
            df_f = df_f[df_f[COL_RULE_ID].isin(sel_rule)]
        df_f = df_f[df_f["Risk Score"] >= score_flt]
        if search_q:
            sq = search_q.lower()
            mask = df_f["Account ID"].astype(str).str.lower().str.contains(sq, na=False)
            # Also check PII fields
            if acc_pii:
                def pii_match(aid):
                    rec = acc_pii.get(aid, {})
                    return any(sq in str(v).lower()
                               for v in [rec.get("name",""), rec.get("phone_number",""),
                                         rec.get("address","")])
                mask = mask | df_f["Account ID"].map(pii_match)
            df_f = df_f[mask]

        # ---- KPI row ----
        k1, k2, k3, k4, k5 = st.columns(5)
        def _kpi(col, label, val, clr):
            col.markdown(f"""<div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                border-radius:10px;padding:12px;text-align:center;">
                <div style="font-size:1.5rem;font-weight:800;color:{clr};">{val:,}</div>
                <div style="font-size:0.68rem;color:#8b9dc3;">{label}</div>
            </div>""", unsafe_allow_html=True)
        _kpi(k1,"Total Violations",len(df_f),"#00b4ff")
        _kpi(k2,"Accounts Affected",df_f["Account ID"].nunique(),"#a78bfa")
        _kpi(k3,"CRITICAL",int((df_f["Severity"]=="CRITICAL").sum()),"#ff3366")
        _kpi(k4,"HIGH",int((df_f["Severity"]=="HIGH").sum()),"#ff8c42")
        _kpi(k5,"FROZEN",sum(1 for a in violations if isinstance(a,dict) and a.get("is_locked")),"#ffd60a")
        st.markdown("<br>", unsafe_allow_html=True)

        # ---- Pattern coverage heatmap ----
        with st.expander("13 Official Mule Pattern Coverage Map", expanded=False):
            rule_counts = df_f[COL_RULE_ID].value_counts().to_dict()
            cols_p = st.columns(3)
            for i, (pat, (desc, reg)) in enumerate(MULE_PATTERNS.items()):
                hit_count = sum(rule_counts.get(r,0) for r in rule_counts
                                if any(kw in pat.lower()
                                       for kw in pat.lower().split()[:2]))
                clr = "#ff3366" if hit_count > 0 else "#8b9dc3"
                cols_p[i % 3].markdown(f"""
                <div style="border-left:3px solid {clr};padding:8px 12px;margin-bottom:8px;
                            background:rgba(255,255,255,0.02);border-radius:0 6px 6px 0;">
                    <div style="font-size:0.75rem;font-weight:700;color:{clr};">{pat}</div>
                    <div style="font-size:0.65rem;color:#8b9dc3;">{reg}</div>
                    <div style="font-size:0.65rem;color:#f0f4ff;margin-top:2px;">{desc[:60]}</div>
                </div>""", unsafe_allow_html=True)

        # ---- Per-account forensic dossiers ----
        st.markdown(f'<div class="section-title">Forensic Dossiers — {min(50,df_f["Account ID"].nunique())} shown</div>',
                    unsafe_allow_html=True)

        for acc_id in df_f["Account ID"].unique()[:50]:
            acc_rows  = df_f[df_f["Account ID"] == acc_id]
            top_row   = acc_rows.iloc[0]
            sev, score, band = top_row["Severity"], top_row["Risk Score"], top_row["Risk Band"]
            color     = SEVERITY_COLORS.get(sev, "#8b9dc3")
            pii_rec   = acc_pii.get(acc_id, {})

            raw_acc   = next((a for a in violations if isinstance(a,dict)
                              and a.get("account_id") == acc_id), {})
            is_locked   = bool(raw_acc.get("is_locked"))
            lock_reason = raw_acc.get("lock_reason","")
            ev_summary  = raw_acc.get("evidence_summary","")

            # PII fields
            name        = str(pii_rec.get("name","—"))
            phone       = str(pii_rec.get("phone_number","—"))
            gender      = str(pii_rec.get("gender","—"))
            address     = str(pii_rec.get("address","—"))[:80]
            nri         = pii_rec.get("nri_flag","N")
            kyc_ok      = pii_rec.get("kyc_compliant","—")
            scheme      = pii_rec.get("scheme_code","—")
            product     = pii_rec.get("product_family","—")
            branch_city = pii_rec.get("branch_city","—")
            branch_st   = pii_rec.get("branch_state","—")
            branch_type = pii_rec.get("branch_type","—")
            avg_bal     = pii_rec.get("avg_balance",None)
            balance_str = f"INR {avg_bal:,.0f}" if avg_bal is not None else "—"
            freeze_dt   = pii_rec.get("freeze_date","—")

            label = (f"{'[FROZEN] ' if is_locked else ''}"
                     f"{sev} | {acc_id} | {name} | Score: {score:.4f} | "
                     f"{len(acc_rows)} violations")

            with st.expander(label, expanded=(sev == "CRITICAL")):
                # Header
                lock_html = (
                    f'<div style="background:rgba(255,51,102,0.12);border-radius:6px;padding:8px 14px;'
                    f'margin-bottom:10px;font-size:0.78rem;color:#ff3366;font-weight:700;">'
                    f'FORENSIC FREEZE: {lock_reason}</div>'
                ) if is_locked else ""

                st.markdown(f"""
                <div style="border-left:4px solid {color};padding:16px;
                            background:rgba(255,255,255,0.03);border-radius:0 10px 10px 0;margin-bottom:12px;">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                        <div>
                            <div style="font-size:0.62rem;color:#8b9dc3;letter-spacing:0.1em;">FORENSIC INVESTIGATION REPORT — RBI NFPC PHASE 2</div>
                            <div style="font-size:1.3rem;font-weight:800;font-family:'JetBrains Mono';color:#f0f4ff;">{acc_id}</div>
                            <div style="font-size:0.78rem;color:#8b9dc3;margin-top:2px;">Risk Band: <span style="color:{color};font-weight:700;">{band}</span></div>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:2rem;font-weight:900;color:{color};">{score:.4f}</div>
                            <div style="font-size:0.62rem;color:#8b9dc3;">MULE PROBABILITY</div>
                        </div>
                    </div>
                    {lock_html}
                </div>""", unsafe_allow_html=True)

                # PII + Account Details grid
                d1, d2, d3 = st.columns(3)
                with d1:
                    st.markdown(f"""
                    <div style="background:rgba(0,180,255,0.05);border:1px solid rgba(0,180,255,0.15);
                                border-radius:8px;padding:12px;">
                        <div style="font-size:0.62rem;color:#8b9dc3;font-weight:700;margin-bottom:6px;">CUSTOMER IDENTITY</div>
                        <div style="font-size:0.82rem;font-weight:700;color:#f0f4ff;">{name}</div>
                        <div style="font-size:0.72rem;color:#8b9dc3;">Gender: {gender} | NRI: {nri}</div>
                        <div style="font-size:0.72rem;color:#a78bfa;margin-top:4px;">Phone: {phone}</div>
                        <div style="font-size:0.68rem;color:#8b9dc3;margin-top:4px;">{address}</div>
                    </div>""", unsafe_allow_html=True)
                with d2:
                    st.markdown(f"""
                    <div style="background:rgba(167,139,250,0.05);border:1px solid rgba(167,139,250,0.15);
                                border-radius:8px;padding:12px;">
                        <div style="font-size:0.62rem;color:#8b9dc3;font-weight:700;margin-bottom:6px;">ACCOUNT PROFILE</div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">KYC: <span style="color:{'#00e096' if kyc_ok=='Y' else '#ff3366'};font-weight:700;">{kyc_ok}</span></div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">Scheme: <span style="color:#ffd60a;font-weight:700;">{scheme}</span></div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">Product: {product}</div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">Avg Balance: {balance_str}</div>
                        <div style="font-size:0.68rem;color:#{('ff3366' if freeze_dt and freeze_dt != 'nan' and freeze_dt != '—' else '8b9dc3')};">
                            Freeze Date: {freeze_dt}</div>
                    </div>""", unsafe_allow_html=True)
                with d3:
                    st.markdown(f"""
                    <div style="background:rgba(255,140,66,0.05);border:1px solid rgba(255,140,66,0.15);
                                border-radius:8px;padding:12px;">
                        <div style="font-size:0.62rem;color:#8b9dc3;font-weight:700;margin-bottom:6px;">BRANCH INTELLIGENCE</div>
                        <div style="font-size:0.82rem;font-weight:700;color:#f0f4ff;">{branch_city}, {branch_st}</div>
                        <div style="font-size:0.72rem;color:#8b9dc3;">Type: {branch_type}</div>
                        <div style="font-size:0.7rem;color:#8b9dc3;margin-top:4px;">{ev_summary[:100]}</div>
                    </div>""", unsafe_allow_html=True)

                st.markdown("<div style='margin-top:12px;'><b>Statutory Violations:</b></div>", unsafe_allow_html=True)
                for _, vrow in acc_rows.iterrows():
                    vcol = SEVERITY_COLORS.get(vrow["Severity"], "#8b9dc3")
                    st.markdown(f"""
                    <div style="background:rgba(255,255,255,0.02);border:1px solid {vcol}33;
                                border-left:3px solid {vcol};border-radius:8px;
                                padding:12px 16px;margin-bottom:8px;">
                        <div style="display:grid;grid-template-columns:1fr 1.5fr 1fr;gap:12px;">
                            <div>
                                <div style="font-size:0.58rem;color:#8b9dc3;letter-spacing:0.08em;">RULE</div>
                                <div style="font-size:0.82rem;font-weight:700;color:{vcol};">{vrow.get(COL_RULE_ID,'')}</div>
                                <div style="font-size:0.72rem;color:#f0f4ff;">{vrow.get('Violation','')}</div>
                            </div>
                            <div>
                                <div style="font-size:0.58rem;color:#8b9dc3;letter-spacing:0.08em;">STATUTORY CITATION</div>
                                <div style="font-size:0.72rem;color:#a78bfa;font-style:italic;">{vrow.get('Statute','')}</div>
                            </div>
                            <div>
                                <div style="font-size:0.58rem;color:#8b9dc3;letter-spacing:0.08em;">ENFORCEMENT ACTION</div>
                                <div style="font-size:0.72rem;color:#00e096;">{vrow.get('Required Action','')}</div>
                            </div>
                        </div>
                        <div style="margin-top:8px;">
                            <div style="font-size:0.58rem;color:#8b9dc3;">FORENSIC EVIDENCE</div>
                            <div style="font-size:0.72rem;color:#f0f4ff;">{vrow.get('Evidence','')}</div>
                        </div>
                    </div>""", unsafe_allow_html=True)

                # Download button
                dossier = {
                    "account_id": acc_id, "risk_score": float(score), "risk_band": band,
                    "is_frozen": is_locked, "freeze_reason": lock_reason,
                    "identity": {"name": name, "phone": phone, "gender": gender,
                                 "address": address, "nri": nri, "scheme": scheme,
                                 "kyc_compliant": kyc_ok, "avg_balance": balance_str,
                                 "branch": f"{branch_city}, {branch_st} ({branch_type})"},
                    "violations": acc_rows[[COL_RULE_ID,"Violation","Severity",
                                           "Statute","Evidence","Required Action"]].to_dict(orient="records"),
                }
                st.download_button("Download Case Dossier (JSON)",
                                   data=json.dumps(dossier, indent=2),
                                   file_name=f"dossier_{acc_id}.json",
                                   mime="application/json",
                                   key=f"dl_{acc_id}")

        if df_f["Account ID"].nunique() > 50:
            st.warning(f"Showing top 50 of {df_f['Account ID'].nunique()} accounts. Use filters.")

        # ---- Rule breach chart ----
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<div class="section-title">Violations by Statutory Rule</div>', unsafe_allow_html=True)
        rule_grp = df_f.groupby([COL_RULE_ID,"Severity"]).size().reset_index(name="Count")
        fig_bar  = px.bar(rule_grp, x=COL_RULE_ID, y="Count", color="Severity",
                          color_discrete_map=SEVERITY_COLORS, text="Count")
        fig_bar.update_layout(template="plotly_dark", paper_bgcolor=BG_CLEAR, plot_bgcolor=BG_PLOT,
                              height=320, font_family="Inter",
                              margin={"l":20,"r":20,"t":10,"b":40},
                              legend={"orientation":"h","y":-0.3})
        st.plotly_chart(fig_bar, use_container_width=True)

        # ---- Regulatory Reference Panel ----
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<div class="section-title">Official Regulatory Framework</div>', unsafe_allow_html=True)
        regs = [
            ("PMLA 2002 Sec 3 & 4",       "Money Laundering Offence",          "#ff3366",
             "3-7 yrs rigorous imprisonment + unlimited fine. Covers all mule account facilitation."),
            ("RBI KYC MD 2016 (Nov 2024)", "Master Direction on KYC",           "#ff8c42",
             "Mandatory CDD/EDD, PEP screening, beneficial owner ID, periodic re-KYC every 2 yrs."),
            ("FATF R.10 / R.20",           "CDD & Suspicious Txn Reporting",    "#ffd60a",
             "R.10: CDD for all customers. R.20: STR filing within 7 working days."),
            ("FIU-IND CTR 2023",           "Cash Transaction Report Threshold", "#00e096",
             "INR 10L aggregate cash/month mandatory CTR to FIU-IND within 15 days."),
            ("PMJDY Guidelines 2014",      "Zero-Balance PMJDY Mule Pattern",   "#00b4ff",
             "PMJDY accounts used as pass-through vehicles — scheme_code=PMJDY is a red flag."),
            ("Basel AML Index 2024",       "Country AML Risk Score",            "#a78bfa",
             "India: 5.55/10. Cross-border corridors and rural branches are elevated risk zones."),
        ]
        rc1, rc2, rc3 = st.columns(3)
        for i, (title, sub, clr, det) in enumerate(regs):
            [rc1, rc2, rc3][i%3].markdown(f"""
            <div style="background:rgba(255,255,255,0.03);border:1px solid {clr}33;
                        border-top:3px solid {clr};border-radius:10px;padding:14px;margin-bottom:12px;">
                <div style="font-size:0.78rem;font-weight:700;color:{clr};">{title}</div>
                <div style="font-size:0.68rem;color:#f0f4ff;font-weight:600;margin:4px 0;">{sub}</div>
                <div style="font-size:0.65rem;color:#8b9dc3;">{det}</div>
            </div>""", unsafe_allow_html=True)

'''

# === TAB 5 REPLACEMENT ===
TAB5_MARKER_START = "# TAB 5: Geo Intelligence"
TAB5_MARKER_END   = "# TAB 6: Account Deep-Dive"

TAB5_NEW = '''# TAB 5: Geo Intelligence -- Supreme 3D Globe (CartoGL, no API key)
# ===============================================================================
with tabs[4]:
    st.markdown(
        '<div class="section-title">Geographic Intelligence -- 3D Forensic Globe</div>'
        '<div class="section-sub">Real-world geo-routes of suspicious transactions. '
        'Curved arc connections color-coded by mule probability. '
        '3D hexagonal density towers. Fly-To precision zoom per account.</div>',
        unsafe_allow_html=True
    )

    import pydeck as pdk

    arc_data = load_geo_arcs()

    if not arc_data:
        st.info("No geographic anomalies detected. Run the full pipeline to populate geo_arcs.json.")
    else:
        # ---- Controls ----
        gc1, gc2, gc3 = st.columns([2, 1, 1])
        with gc1:
            top_ids = [a["account_id"] for a in arc_data if isinstance(a, dict)]
            sel_tgt = st.selectbox("Fly-To Target Account",
                                   ["Global View (India Focus)"] + top_ids)
        with gc2:
            map_theme = st.selectbox("Map Style", ["Dark (Forensic)", "Satellite", "Light"])
        with gc3:
            show_hex = st.checkbox("Show 3D Towers", value=True)

        CARTO = {
            "Dark (Forensic)": "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json",
            "Satellite":       "https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json",
            "Light":           "https://basemaps.cartocdn.com/gl/positron-gl-style/style.json",
        }

        view = pdk.ViewState(
            longitude=78.9629, latitude=20.5937,
            zoom=3.8, pitch=55, bearing=10,
            max_zoom=18, min_zoom=1,
        )
        fly_label = ""
        if sel_tgt != "Global View (India Focus)":
            t = next((a for a in arc_data if isinstance(a,dict) and a["account_id"]==sel_tgt), None)
            if t and isinstance(t.get("target"), list):
                view = pdk.ViewState(
                    longitude=t["target"][0], latitude=t["target"][1],
                    zoom=12, pitch=60, bearing=20,
                )
                fly_label = (f"Account: {sel_tgt}  |  "
                             f"Lat: {t['target'][1]:.4f}  |  Lng: {t['target'][0]:.4f}  |  "
                             f"Mule Prob: {t.get('mule_prob',0):.3f}")
        if fly_label:
            st.success(f"Fly-To: {fly_label}")

        # ---- Arc Layer (curved geo-routes) ----
        arc_layer = pdk.Layer(
            "ArcLayer",
            data=[a for a in arc_data if isinstance(a, dict)
                  and isinstance(a.get("source"), list)
                  and isinstance(a.get("target"), list)],
            get_source_position="source",
            get_target_position="target",
            get_source_color="[int(255*mule_prob), int(51*(1-mule_prob)), 102, 220]",
            get_target_color="[0, int(224*(1-mule_prob)+51*mule_prob), 150, 220]",
            get_width="2 + 18*mule_prob",
            get_tilt=15,
            pickable=True,
            auto_highlight=True,
        )

        # ---- Hexagon Density Towers ----
        hex_pts = []
        for a in arc_data:
            if not isinstance(a, dict): continue
            if isinstance(a.get("source"), list):
                hex_pts.append({"position": a["source"], "weight": a.get("mule_prob", 0.5)})
            if isinstance(a.get("target"), list):
                hex_pts.append({"position": a["target"], "weight": a.get("mule_prob", 0.5)})

        hex_layer = pdk.Layer(
            "HexagonLayer",
            data=hex_pts,
            get_position="position",
            get_weight="weight",
            radius=40000,
            elevation_scale=8000,
            elevation_range=[0, 6000],
            extruded=True,
            pickable=True,
            coverage=0.8,
            get_fill_color=[255, 51, 102, 160],
        )

        # ---- Scatter: origin points ----
        scatter_layer = pdk.Layer(
            "ScatterplotLayer",
            data=[{"position": a["source"],
                   "account_id": a.get("account_id",""),
                   "name": a.get("name",""),
                   "mule_prob": a.get("mule_prob", 0)}
                  for a in arc_data
                  if isinstance(a, dict) and isinstance(a.get("source"), list)],
            get_position="position",
            get_fill_color=[255, 51, 102, 200],
            get_radius="3000 + 30000*mule_prob",
            pickable=True,
            opacity=0.7,
            stroked=True,
            get_line_color=[255, 255, 255, 80],
            line_width_min_pixels=1,
        )

        layers = [arc_layer, scatter_layer]
        if show_hex:
            layers.insert(0, hex_layer)

        deck = pdk.Deck(
            layers=layers,
            initial_view_state=view,
            map_style=CARTO[map_theme],
            tooltip={
                "html": (
                    "<b>Account:</b> {account_id}<br>"
                    "<b>Name:</b> {name}<br>"
                    "<b>Mule Probability:</b> {mule_prob}<br>"
                    "<b>From:</b> {source}<br>"
                    "<b>To:</b> {target}"
                ),
                "style": {
                    "background": "rgba(5,11,24,0.92)",
                    "color": "#f0f4ff",
                    "font-family": "Inter",
                    "padding": "10px",
                    "border-radius": "8px",
                },
            },
        )
        st.pydeck_chart(deck, use_container_width=True)

        # ---- Stats ----
        st.markdown("<br>", unsafe_allow_html=True)
        gs1, gs2, gs3, gs4 = st.columns(4)
        probs = [a.get("mule_prob",0) for a in arc_data if isinstance(a,dict)]
        gs1.metric("Total Geo-Arcs", f"{len(arc_data):,}")
        gs2.metric("High-Risk (>0.8)", f"{sum(1 for p in probs if p>0.8):,}")
        gs3.metric("Avg Mule Prob", f"{sum(probs)/max(len(probs),1):.3f}")
        gs4.metric("Unique Accounts", f"{len({a['account_id'] for a in arc_data if isinstance(a,dict)}):,}")

        st.markdown("---")
        gi1, gi2 = st.columns(2)
        with gi1:
            st.info("Detection Logic: Clustered access from distinct jurisdictions targeting"
                    " single recipient pools. Impossible Travel >1,500 km/hr triggers INT-AML-010.")
        with gi2:
            st.success("Globe powered by CartoGL dark-matter tiles (no MapBox key required)."
                       " All lat/lng sourced from real transactions_additional.parquet GPS data.")

'''

# ---- Perform the patch ----
original = DASH.read_text(encoding="utf-8")

# Normalize line endings
lines = original.splitlines(keepends=True)

def find_section(lines, start_marker, end_marker):
    si = ei = None
    for i, line in enumerate(lines):
        if si is None and start_marker in line:
            # Go back to find the comment block start
            si = i - 1 if i > 0 and lines[i-1].strip().startswith("#") else i
        if si is not None and end_marker in line:
            ei = i
            break
    return si, ei

# Replace TAB 2
si2, ei2 = find_section(lines, TAB2_MARKER_START, TAB2_MARKER_END)
if si2 is not None and ei2 is not None:
    # keep from start up to si2, then inject TAB2_NEW, then continue from ei2
    lines = lines[:si2] + [TAB2_NEW + "\n"] + lines[ei2:]
    print(f"[OK] TAB 2 replaced at lines {si2}-{ei2}")
else:
    print(f"[WARN] Could not locate TAB 2 markers in dashboard.py")

# After TAB 2 replacement, re-find TAB 5 (line numbers shifted)
si5, ei5 = find_section(lines, TAB5_MARKER_START, TAB5_MARKER_END)
if si5 is not None and ei5 is not None:
    lines = lines[:si5] + [TAB5_NEW + "\n"] + lines[ei5:]
    print(f"[OK] TAB 5 replaced at lines {si5}-{ei5}")
else:
    print(f"[WARN] Could not locate TAB 5 markers in dashboard.py")

DASH.write_text("".join(lines), encoding="utf-8")
print("[DONE] dashboard.py patched successfully.")
