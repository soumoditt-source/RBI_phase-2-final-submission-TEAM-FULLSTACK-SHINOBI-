"""
DEFINITIVE Money Chain Builder v2
====================================
Fixed: Uses G.edge_list() instead of successor_indices() (more reliable in rustworkx).
Scans ALL b1_part_*.parquet transaction partitions, builds PageRank graph,
saves results/money_chain.json with correct nodes + links.
"""
import json, glob, logging
from pathlib import Path
import polars as pl, pandas as pd, rustworkx as rx

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("MoneyChain")

ROOT = Path(__file__).parent
RESULTS = ROOT / "results"


def run():
    log.info("=" * 60)
    log.info("   MONEY CHAIN DEFINITIVE BUILDER v2")
    log.info("=" * 60)

    # Step 1: Load HFT features for risk scoring
    hft_path = RESULTS / "hft_features.parquet"
    if not hft_path.exists():
        log.error("HFT features not found.")
        return

    hft = pd.read_parquet(hft_path, columns=[
        "account_id", "hft_total_volume", "hft_structuring_count", "hft_credit_vol"
    ])
    hft["account_id"] = hft["account_id"].astype(str)
    hft["risk_proxy"] = (
        hft["hft_structuring_count"].fillna(0) * 3
        + hft["hft_credit_vol"].fillna(0) / (hft["hft_total_volume"].fillna(1) + 1) * 100
    )
    top_risk = set(hft.nlargest(6000, "risk_proxy")["account_id"].tolist())
    log.info(f"High-risk pool size: {len(top_risk)}")

    # Load submission scores for display
    scores = {}
    sub_path = ROOT / "submission.csv"
    if sub_path.exists():
        sub = pd.read_csv(sub_path, usecols=["account_id", "is_mule"])
        sub["account_id"] = sub["account_id"].astype(str)
        scores = dict(zip(sub["account_id"], sub["is_mule"]))
        sub_high = set(sub[sub["is_mule"] > 0.3]["account_id"].tolist())
        top_risk = top_risk | sub_high
        log.info(f"Extended pool (incl submission signals): {len(top_risk)}")

    # Step 2: Scan all b1_part_*.parquet partitions
    parquet_files = sorted(glob.glob(str(RESULTS / "b1_part_*.parquet")))
    log.info(f"Scanning {len(parquet_files)} transaction partitions...")

    chunks = []
    for pf in parquet_files:
        try:
            df = pl.read_parquet(pf, columns=["account_id", "counterparty_id", "amount"])
            filtered = df.filter(pl.col("account_id").is_in(list(top_risk)))
            if len(filtered) > 0:
                chunks.append(filtered)
        except Exception as e:
            log.warning(f"  Skip {Path(pf).name}: {e}")

    if not chunks:
        log.error("No matching edges found.")
        return

    all_edges = pl.concat(chunks)
    log.info(f"Raw transaction edges (high-risk accounts): {len(all_edges):,}")

    # Step 3: Aggregate edges by src→tgt pair
    cp_agg = (
        all_edges
        .group_by(["account_id", "counterparty_id"])
        .agg([
            pl.col("amount").abs().sum().alias("total_vol"),
            pl.len().alias("txn_count"),
        ])
        .sort("total_vol", descending=True)
        .to_pandas()
    )
    log.info(f"Unique account→counterparty edges: {len(cp_agg):,}")

    # Step 4: Build Rustworkx directed graph
    G = rx.PyDiGraph(multigraph=False)
    node_map = {}  # account_id -> graph node index
    edge_meta = {}  # (u, v) -> {weight, count}

    def get_or_add(acc_id):
        s = str(acc_id)
        if s not in node_map:
            node_map[s] = G.add_node(s)
        return node_map[s]

    max_edges = 60000
    for _, row in cp_agg.head(max_edges).iterrows():
        src, tgt = str(row["account_id"]), str(row["counterparty_id"])
        u = get_or_add(src)
        v = get_or_add(tgt)
        w = float(row["total_vol"])
        c = int(row["txn_count"])
        try:
            G.add_edge(u, v, w)
            edge_meta[(u, v)] = {"weight": w, "count": c}
        except Exception:
            pass  # multigraph=False silently drops duplicates

    log.info(f"Graph: {len(G)} nodes, {G.num_edges()} edges")

    # Step 5: PageRank
    log.info("Computing PageRank...")
    try:
        pr_raw = rx.pagerank(G, weight_fn=lambda e: max(float(e), 0.01) if e else 0.01)
        pr = {idx: float(v) for idx, v in pr_raw.items()}
    except Exception as e:
        log.warning(f"PageRank fallback: {e}")
        pr = {idx: float(G.in_degree(idx)) for idx in G.node_indices()}

    max_pr = max(pr.values()) if pr else 1.0

    def pr_percent(idx):
        return pr.get(idx, 0.0) / (max_pr + 1e-9) * 100

    # Step 6: Top 150 hubs
    sorted_nmap = sorted(node_map.items(), key=lambda kv: pr.get(kv[1], 0), reverse=True)
    top_hubs = {acc: idx for acc, idx in sorted_nmap[:150]}
    top_hub_indices = set(top_hubs.values())
    log.info(f"Top {len(top_hubs)} hub accounts identified by PageRank")

    # Step 7: Build output nodes
    nodes_out = []
    for acc, idx in top_hubs.items():
        ps = pr_percent(idx)
        role = "MULE_HUB" if ps > 5 else "COLLECTOR" if ps > 1 else "SMURFER"
        nodes_out.append({
            "id": acc,
            "label": f"[{role}] {acc[:8]}",
            "role": role,
            "score": round(float(scores.get(acc, hft.set_index("account_id")["risk_proxy"].get(acc, 0.45)
                                 if acc in hft.set_index("account_id").index else 0.45)), 4),
            "size": max(10, min(60, int(ps * 3 + 10))),
            "color": "#ff3366" if role == "MULE_HUB" else "#ff8c42" if role == "COLLECTOR" else "#ffd60a",
            "pagerank": round(ps, 4),
        })

    # Step 8: Build links using G.edge_list() — avoids successor_indices() bug
    log.info("Extracting links via G.edge_list()...")
    links_out = []
    leaf_nodes_to_add = {}

    edge_list = G.edge_list()
    for (u, v) in edge_list:
        src_acc = str(G[u])
        tgt_acc = str(G[v])
        # Only include edges where source is a top hub
        if u not in top_hub_indices:
            continue
        meta = edge_meta.get((u, v), {"weight": 1.0, "count": 1})
        links_out.append({
            "source": src_acc,
            "target": tgt_acc,
            "value": round(float(meta["weight"]) / 1e6, 4),  # INR millions
            "count": int(meta["count"]),
        })
        if v not in top_hub_indices:
            leaf_nodes_to_add[tgt_acc] = v

    log.info(f"Links generated: {len(links_out)}")

    # Add leaf nodes
    hft_idx = hft.set_index("account_id")
    for tgt_acc, v in leaf_nodes_to_add.items():
        ps = pr_percent(v)
        nodes_out.append({
            "id": tgt_acc,
            "label": f"[LEAF] {tgt_acc[:8]}",
            "role": "LEAF",
            "score": round(float(scores.get(tgt_acc, 0.2)), 4),
            "size": 8,
            "color": "#8b9dc3",
            "pagerank": round(ps, 4),
        })

    log.info(f"Total nodes: {len(nodes_out)}, Total links: {len(links_out)}")

    # Sort links by value descending, cap at 500 for browser performance
    links_sorted = sorted(links_out, key=lambda l: l["value"], reverse=True)[:500]

    out = {
        "nodes": nodes_out,
        "links": links_sorted,
        "meta": {
            "total_edge_rows_scanned": len(cp_agg),
            "partitions_scanned": len(parquet_files),
            "high_risk_pool_size": len(top_risk),
            "graph_nodes": len(G),
            "graph_edges": G.num_edges(),
        }
    }

    out_path = RESULTS / "money_chain.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, default=str)

    log.info(f"✅ Saved: {out_path}")
    log.info(f"   Nodes: {len(nodes_out)}, Links: {len(links_sorted)}")
    log.info("=" * 60)


if __name__ == "__main__":
    run()
