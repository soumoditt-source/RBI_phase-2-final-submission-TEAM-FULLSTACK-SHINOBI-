import polars as pl
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("TestHFT")

files = sorted(list(Path("results").glob("b*.parquet")))
if files:
    f = files[0]
    df = pl.read_parquet(f)
    log.info(f"File {f} account_id type: {df['account_id'].dtype}")
    
    from src.data.pipeline import DataPipeline
    master = DataPipeline().load_account_master()
    log.info(f"Master account_id type: {master['account_id'].dtype}")
    
    # Try the join
    # First, let's aggregate a small sample
    sample_agg = df.head(100).group_by("account_id").agg([pl.len().alias("count")])
    log.info(f"Sample agg account_id type: {sample_agg['account_id'].dtype}")
    
    try:
        joined = master.join(sample_agg, on="account_id", how="inner")
        log.info(f"Inner Join result rows: {len(joined)}")
    except Exception as e:
        log.error(f"Join failed: {e}")
