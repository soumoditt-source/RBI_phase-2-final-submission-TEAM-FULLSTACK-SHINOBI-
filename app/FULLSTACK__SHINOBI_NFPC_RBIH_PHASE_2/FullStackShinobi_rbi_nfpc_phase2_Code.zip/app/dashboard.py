"""
MuleHunter.AI — Production Forensic Intelligence Dashboard
============================================================
7-Tab glassmorphic Streamlit dashboard. Judge-grade design.
Loads: submission.csv + account_violations.json + shap_importance.csv

Tabs:
  1. Mission Control      — Live KPI scorecards
  2. Violations Ledger    — Statutory violations table per account
  3. Money Network        — Graph of mule hubs and edges
  4. Temporal Forensics   — Burst timeline heatmaps
  5. Geo Intelligence     — Impossible travel map
  6. Account Deep-Dive    — Full per-account police report
  7. Model Explainability — SHAP, AUC, Venn-Abers

Run: streamlit run app/dashboard.py
"""

from __future__ import annotations
import json
import os
import sys
from pathlib import Path
from typing import Optional

try:
    import numpy as np
    import pandas as pd
    import plotly.express as px
    import plotly.graph_objects as go
    import streamlit as st
    import polars as pl
except ImportError as e:
    print(f"--- MULEHUNTER DASHBOARD ERROR: Missing Dependency ({e.name}) ---")
    print("Please run: pip install -r requirements.txt")
    sys.exit(1)

# ─────────────────────────────────────────────────────────────────────────────
# Page Config
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="MuleHunter.AI | RBI NFPC Phase 2 Forensic Intelligence Platform",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "Get Help": None,
        "Report a bug": None,
        "About": "MuleHunter.AI | National Fraud Prevention Challenge Phase 2 | Team FullStackShinobi",
    },
)

# ─────────────────────────────────────────────────────────────────────────────
# Custom CSS — Glassmorphic Dark Theme with Animated Gradients
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap');

:root {
    --bg-primary: #050b18;
    --bg-secondary: #0a1628;
    --glass-bg: rgba(255,255,255,0.04);
    --glass-border: rgba(255,255,255,0.08);
    --accent-red: #ff3366;
    --accent-orange: #ff8c42;
    --accent-yellow: #ffd60a;
    --accent-green: #00e096;
    --accent-blue: #00b4ff;
    --accent-purple: #a78bfa;
    --text-primary: #f0f4ff;
    --text-secondary: #8b9dc3;
}

html, body, .stApp {
    background: linear-gradient(135deg, #050b18 0%, #0a1628 40%, #0d1f3c 70%, #050b18 100%) !important;
    font-family: 'Inter', sans-serif !important;
    color: var(--text-primary) !important;
}

/* Animated gradient header */
.dashboard-header {
    background: linear-gradient(90deg, #ff3366, #ff8c42, #ffd60a, #00e096, #00b4ff, #a78bfa, #ff3366);
    background-size: 400% 400%;
    animation: gradientShift 8s ease infinite;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-size: 2.8rem;
    font-weight: 900;
    letter-spacing: -0.02em;
    text-align: center;
    padding: 10px 0;
}
@keyframes gradientShift {
    0%   { background-position: 0% 50%; }
    50%  { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* KPI Cards */
.kpi-card {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 16px;
    padding: 24px;
    backdrop-filter: blur(16px);
    transition: all 0.3s ease;
    text-align: center;
}
.kpi-card:hover {
    border-color: rgba(0, 180, 255, 0.4);
    box-shadow: 0 0 24px rgba(0, 180, 255, 0.15);
    transform: translateY(-2px);
}
.kpi-value {
    font-size: 2.4rem;
    font-weight: 800;
    line-height: 1.0;
}
.kpi-label { font-size: 0.8rem; color: var(--text-secondary); margin-top: 6px; letter-spacing: 0.08em; text-transform: uppercase; }

/* Violation badges */
.badge-critical { background: rgba(255,51,102,0.2); color: #ff3366; border: 1px solid rgba(255,51,102,0.4); border-radius: 6px; padding: 2px 10px; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em; }
.badge-high     { background: rgba(255,140,66,0.2);  color: #ff8c42; border: 1px solid rgba(255,140,66,0.4); border-radius: 6px; padding: 2px 10px; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em; }
.badge-medium   { background: rgba(255,214,10,0.2);  color: #ffd60a; border: 1px solid rgba(255,214,10,0.4); border-radius: 6px; padding: 2px 10px; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em; }
.badge-low      { background: rgba(0,224,150,0.2);   color: #00e096; border: 1px solid rgba(0,224,150,0.4); border-radius: 6px; padding: 2px 10px; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em; }
.badge-clear    { background: rgba(139,157,195,0.1); color: #8b9dc3; border: 1px solid rgba(139,157,195,0.2); border-radius: 6px; padding: 2px 10px; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em; }

/* Police Report Card */
.police-card {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px;
    padding: 20px;
    margin: 12px 0;
    backdrop-filter: blur(12px);
}
.police-card-critical { border-left: 4px solid #ff3366; }
.police-card-high     { border-left: 4px solid #ff8c42; }
.police-card-medium   { border-left: 4px solid #ffd60a; }
.police-card-clear    { border-left: 4px solid #00e096; }

/* Section headers */
.section-title {
    font-size: 1.1rem; font-weight: 700; color: var(--text-primary);
    letter-spacing: 0.04em; margin-bottom: 4px;
}
.section-sub {
    font-size: 0.8rem; color: var(--text-secondary); margin-bottom: 16px;
}

/* Streamlit overrides */
.stTabs [data-baseweb="tab-list"] {
    background: rgba(255,255,255,0.03) !important;
    border-radius: 12px;
    gap: 8px;
    padding: 4px;
}
.stTabs [data-baseweb="tab"] {
    border-radius: 8px !important;
    font-weight: 600 !important;
    color: var(--text-secondary) !important;
    font-size: 0.85rem !important;
}
.stTabs [aria-selected="true"] {
    background: rgba(0,180,255,0.15) !important;
    color: #00b4ff !important;
    border-bottom: 2px solid #00b4ff !important;
}
/* Glassmorphic Background for whole app */
.stApp {
    background: radial-gradient(circle at top right, #0a1936, #050b18),
                radial-gradient(circle at bottom left, #0d1f3c, #050b18) !important;
}

/* Premium Sidebar */
section[data-testid="stSidebar"] {
    background: rgba(10, 22, 40, 0.8) !important;
    backdrop-filter: blur(20px);
    border-right: 1px solid rgba(255,255,255,0.05);
}

/* Enhanced KPI Cards */
.kpi-card {
    background: linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 30px;
    backdrop-filter: blur(25px);
    box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.kpi-card:hover {
    transform: translateY(-5px) scale(1.02);
    border-color: #00b4ff;
    box-shadow: 0 0 30px rgba(0, 180, 255, 0.2);
}

/* Animated Underline for section titles */
.section-title::after {
    content: '';
    display: block;
    width: 40px;
    height: 3px;
    background: #00b4ff;
    margin-top: 8px;
    border-radius: 2px;
}

/* Tab styling */
.stTabs [data-baseweb="tab-list"] {
    background: rgba(255,255,255,0.02) !important;
    padding: 5px;
    border-radius: 15px;
}

/* Glass effect for DataFrames */
[data-testid="stDataFrame"] {
    background: rgba(255,255,255,0.02);
    border-radius: 10px;
    padding: 10px;
}

/* Glow effects */
.glow-red { filter: drop-shadow(0 0 8px rgba(255, 51, 102, 0.4)); }
.glow-blue { filter: drop-shadow(0 0 8px rgba(0, 180, 255, 0.4)); }

/* Scanner Animation */
@keyframes scanline {
    0% { transform: translateY(-100%); }
    100% { transform: translateY(100%); }
}
.scanner-effect {
    position: relative;
    overflow: hidden;
}
.scanner-effect::after {
    content: "";
    position: absolute;
    top: 0; left: 0; width: 100%; height: 2px;
    background: rgba(0, 180, 255, 0.5);
    box-shadow: 0 0 8px #00b4ff;
    animation: scanline 3s linear infinite;
}

/* Lock Overlay */
.lock-indicator {
    background: rgba(255, 51, 102, 0.15);
    border: 1px solid #ff3366;
    border-radius: 8px;
    padding: 8px 16px;
    color: #ff3366;
    font-weight: 800;
    font-size: 0.8rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Data Loading
# ─────────────────────────────────────────────────────────────────────────────
DATA_DIR = Path(__file__).parent.parent

@st.cache_data(ttl=900, show_spinner="🛰️ Syncing Global Submission...")
def load_submission() -> pd.DataFrame:
    p = DATA_DIR / "submission.csv"
    if not p.exists():
        return pd.DataFrame(columns=["account_id","is_mule","suspicious_start","suspicious_end"])
    df = pd.read_csv(p, dtype={"suspicious_start": str, "suspicious_end": str})
    if "suspicious_start" in df.columns:
        df["suspicious_start"] = pd.to_datetime(df["suspicious_start"], errors="coerce")
    if "suspicious_end" in df.columns:
        df["suspicious_end"] = pd.to_datetime(df["suspicious_end"], errors="coerce")
    return df

@st.cache_data(ttl=900, show_spinner="⚖️ Gathering Forensic Violations...")
def load_violations() -> list:
    # Check both root and results/ subdirectory
    for candidate in [
        DATA_DIR / "results" / "account_violations.json",
        DATA_DIR / "account_violations.json",
    ]:
        if candidate.exists():
            try:
                with open(candidate, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    return data
                elif isinstance(data, dict):
                    # Unwrap if wrapped in a dict
                    for key in ["violations", "accounts", "data", "records"]:
                        if key in data and isinstance(data[key], list):
                            return data[key]
                    return [data]  # single record
            except (json.JSONDecodeError, OSError):
                pass
    return []

@st.cache_data(ttl=900, show_spinner="🧠 Explaining Forensic Models...")
def load_shap() -> pd.DataFrame:
    for candidate in [
        DATA_DIR / "notebooks" / "shap_importance.csv",
        DATA_DIR / "results" / "shap_importance.csv",
        DATA_DIR / "shap_importance.csv",
    ]:
        if candidate.exists():
            return pd.read_csv(candidate)
    return pd.DataFrame(columns=["feature", "mean_abs_shap"])

@st.cache_data(ttl=900, show_spinner="⚙️ Analyzing Money Chain Nodes...")
def load_money_chain():
    p = DATA_DIR / "results" / "money_chain.json"
    try:
        if p.exists():
            with open(p, "r") as f: return json.load(f)
    except Exception: pass
    return {"links": [], "nodes": []}

@st.cache_data(ttl=86400, show_spinner="🗺️ Mapping 3D Geo-Arcs...")
def load_geo_arcs():
    p = DATA_DIR / "results" / "geo_arcs.json"
    try:
        if p.exists():
            with open(p, "r") as f: 
                data = json.load(f)
                return data
    except (OSError, json.JSONDecodeError): pass
    return []

# ─────────────────────────────────────────────────────────────────────────────
# Constants (defined BEFORE they are used below)
# ─────────────────────────────────────────────────────────────────────────────
COL_RULE_ID = "Rule ID"
COL_FLAGGED = "Flagged Accounts"
COL_BRANCH  = "Branch Count"
BG_CLEAR    = "rgba(0,0,0,0)"
BG_PLOT     = "rgba(255,255,255,0.02)"

SEVERITY_COLORS = {
    "CRITICAL": "#ff3366",
    "HIGH":     "#ff8c42",
    "MEDIUM":   "#ffd60a",
    "LOW":      "#00e096",
    "CLEAR":    "#8b9dc3",
}
RISK_BAND_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "CLEAR"]

def violations_to_df(violations: list) -> pd.DataFrame:
    """Convert account_violations.json into a flat DataFrame.
    Handles both account-grouped format and flat violation list format.
    """
    if not violations:
        return pd.DataFrame()
    rows = []
    for acc in violations:
        # Format A: {account_id, risk_score, violations: [...]}
        if isinstance(acc, dict) and "violations" in acc and isinstance(acc["violations"], list):
            for v in acc["violations"]:
                if not isinstance(v, dict):
                    continue
                rows.append({
                    "Account ID":      acc.get("account_id", ""),
                    "Risk Score":      round(float(acc.get("risk_score", 0)), 4),
                    "Risk Band":       acc.get("risk_band", ""),
                    COL_RULE_ID:       v.get("rule_id", ""),
                    "Violation":       v.get("rule_name", ""),
                    "Severity":        v.get("category", ""),
                    "Statute":         str(v.get("statute", ""))[:60],
                    "Evidence":        str(v.get("evidence_detail", ""))[:80],
                    "Required Action": str(v.get("required_action", ""))[:70],
                })
        # Format B: flat violation dict with account_id at top level
        elif isinstance(acc, dict) and "rule_id" in acc:
            rows.append({
                "Account ID":      acc.get("account_id", ""),
                "Risk Score":      round(float(acc.get("risk_score", 0)), 4),
                "Risk Band":       acc.get("risk_band", ""),
                COL_RULE_ID:       acc.get("rule_id", ""),
                "Violation":       acc.get("rule_name", ""),
                "Severity":        acc.get("category", ""),
                "Statute":         str(acc.get("statute", ""))[:60],
                "Evidence":        str(acc.get("evidence_detail", ""))[:80],
                "Required Action": str(acc.get("required_action", ""))[:70],
            })
    return pd.DataFrame(rows)

# ─────────────────────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🔍 MuleHunter.AI")
    st.markdown('<p style="color:#8b9dc3;font-size:0.75rem;margin-top:-8px;">Forensic Intelligence Platform</p>', unsafe_allow_html=True)
    st.markdown("---")
    st.markdown("**NFPC Phase 2** | Team FullStackShinobi")
    st.markdown("**Regulatory Framework:**")
    st.markdown("- PMLA 2002 + PML Rules 2005\n- RBI KYC MD 2016 (Nov 2024)\n- FATF 40 Recommendations (R5)\n- Basel AML Index 2024\n- PMJDY Guidelines 2014\n- RBI NEFT/RTGS/IMPS 2019")
    st.markdown("---")
    st.markdown("**Architecture:**")
    st.markdown("- Dask lazy 16GB ETL\n- rustworkx Graph Engine\n- LGB + XGBoost + Logistic Stack\n- SHAP TreeExplainer\n- Venn-Abers Calibration\n- 10-Rule Legal Engine")
    st.markdown("---")
    score_threshold = st.slider("Score Threshold", 0.01, 1.0, 0.50, 0.01, help="Filter accounts above this risk score")
    st.markdown(f'<p style="color:#8b9dc3;font-size:0.75rem;">Accounts ≥ {score_threshold:.2f} shown as flagged</p>', unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────────────────────
st.markdown('<div class="dashboard-header">MuleHunter.AI Forensic Intelligence Platform</div>', unsafe_allow_html=True)
st.markdown('<p style="text-align:center;color:#8b9dc3;font-size:0.9rem;margin-top:-8px;margin-bottom:24px;">National Fraud Prevention Challenge Phase 2 | RBI | Team FullStackShinobi</p>', unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Load data
# ─────────────────────────────────────────────────────────────────────────────
submission  = load_submission()
violations  = load_violations()
shap_df     = load_shap()
viols_df    = violations_to_df(violations)

pipeline_ready = len(submission) > 0
n_flagged      = int((submission["is_mule"] >= score_threshold).sum()) if pipeline_ready else 0
n_total        = len(submission)
avg_score      = float(submission["is_mule"].mean()) if pipeline_ready else 0.0
# Safe violations summary — handles any JSON format
n_critical = sum(
    1 for a in violations
    if isinstance(a, dict) and (
        a.get("risk_band") == "CRITICAL" or a.get("category") == "CRITICAL"
    )
)
n_high = sum(
    1 for a in violations
    if isinstance(a, dict) and (
        a.get("risk_band") == "HIGH" or a.get("category") == "HIGH"
    )
)
total_viols = sum(
    len(a.get("violations", [])) for a in violations if isinstance(a, dict)
) or len(violations)

# ─────────────────────────────────────────────────────────────────────────────
# Tabs
# ─────────────────────────────────────────────────────────────────────────────
tabs = st.tabs([
    "🏠 Mission Control",
    "📊 EDA: 13 Patterns",
    "🚨 Violations Ledger",
    "🕸️ Money Network",
    "⏱️ Temporal Forensics",
    "🗺️ Geo Intelligence",
    "📋 Account Deep-Dive",
    "🤖 Model Explainability",
])

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1: Mission Control
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[0]:
    if not pipeline_ready:
        st.warning("⏳ Pipeline is still running... `submission.csv` not yet available. Refresh in a few minutes.")
    else:
        # KPI Row 1
        c1, c2, c3, c4, c5 = st.columns(5)
        with c1:
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-value" style="color:#ff3366;">{n_flagged:,}</div>
                <div class="kpi-label">Mule Accounts Flagged</div></div>""", unsafe_allow_html=True)
        with c2:
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-value" style="color:#00b4ff;">{n_total:,}</div>
                <div class="kpi-label">Accounts Analysed</div></div>""", unsafe_allow_html=True)
        with c3:
            pct = (n_flagged/n_total*100) if n_total else 0
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-value" style="color:#ff8c42;">{pct:.2f}%</div>
                <div class="kpi-label">Flag Rate</div></div>""", unsafe_allow_html=True)
        with c4:
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-value" style="color:#ff3366;">{n_critical:,}</div>
                <div class="kpi-label">CRITICAL Risk</div></div>""", unsafe_allow_html=True)
        with c5:
            st.markdown(f"""<div class="kpi-card">
                <div class="kpi-value" style="color:#ffd60a;">{total_viols:,}</div>
                <div class="kpi-label">Total Violations</div></div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        
        # Live Alert Scanner (Shinobi-Ultra)
        mc_col1, mc_col2 = st.columns([1, 1.5])
        
        with mc_col1:
            st.markdown('<div class="section-title">📡 Live Forensic Scanner</div><div class="section-sub">Real-time detection feed from Shinobi-Cortex engine</div>', unsafe_allow_html=True)
            scanner_container = st.container(height=400)

            # account_violations.json is a flat list — each item is one violation record
            # Filter to CRITICAL risk_band items (or items where category == CRITICAL)
            def _is_critical(item: dict) -> bool:
                if not isinstance(item, dict):
                    return False
                return (item.get("risk_band") == "CRITICAL" or
                        item.get("category") == "CRITICAL")

            critical_alerts = [a for a in violations if _is_critical(a)]

            if not critical_alerts:
                scanner_container.info("No active critical threats detected in current forensic batch.")
            else:
                for alert in critical_alerts[:50]:  # Limit for performance
                    if not isinstance(alert, dict):
                        continue
                    # statute lives directly on the flat record
                    statute_cite = str(alert.get("statute", "") or alert.get("rule_name", "RBI/PMLA Regulation"))[:40]
                    scanner_container.markdown(f"""
                    <div class="scanner-effect" style="background:rgba(255,51,102,0.05); border:1px solid rgba(255,51,102,0.2); 
                                 border-radius:8px; padding:12px; margin-bottom:8px;">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span style="color:#ff3366; font-weight:800; font-size:0.75rem;">🚨 CRITICAL THREAT</span>
                            <span style="color:#8b9dc3; font-size:0.65rem;">{alert.get('generated_at', 'FORENSIC_TS')}</span>
                        </div>
                        <div style="font-family:'JetBrains Mono'; font-size:0.9rem; color:#f0f4ff; margin:4px 0;">{alert.get('account_id', 'UNKNOWN')}</div>
                        <div style="font-size:0.7rem; color:#a78bfa; margin-bottom:4px;">{statute_cite}...</div>
                        <div style="font-size:0.75rem; color:#8b9dc3;">{str(alert.get('evidence_detail', alert.get('evidence_summary', '')))[:100]}...</div>
                    </div>
                    """, unsafe_allow_html=True)

        with mc_col2:
            st.markdown('<div class="section-title">Risk Score Distribution</div><div class="section-sub">Full test set — mule probability from ensemble model</div>', unsafe_allow_html=True)
            fig_hist = px.histogram(
                submission, x="is_mule", nbins=80,
                color_discrete_sequence=["#00b4ff"],
                labels={"is_mule": "Mule Probability Score"},
            )
            fig_hist.add_vline(x=score_threshold, line_color="#ff3366", line_dash="dash",
                               annotation_text=f"Threshold {score_threshold:.2f}", annotation_font_color="#ff3366")
            fig_hist.update_layout(
                template="plotly_dark", paper_bgcolor=BG_CLEAR,
                plot_bgcolor=BG_PLOT,
                font_family="Inter", margin={"l": 20, "r": 20, "t": 20, "b": 20},
                showlegend=False, height=350,
            )
            st.plotly_chart(fig_hist, width="stretch", config={"displayModeBar": False})

        # Architecture info box
        st.markdown("---")
        st.markdown('<div class="section-title">System Architecture</div>', unsafe_allow_html=True)
        arch_cols = st.columns(5)
        arch_items = [
            ("16 GB Dataset", "396 txn + 311 txna parquet files\n+ 9 reference tables\n~400M transactions", "#00b4ff"),
            ("Feature Engineering", "Graph (rustworkx)\nTemporal (3 burst triggers)\nSpatial (DBSCAN geo)\nContextual (KYC/product)", "#a78bfa"),
            ("ML Ensemble", "LightGBM + XGBoost\n5-fold OOF stacking\nLogistic meta-learner\nVenn-Abers calibration", "#00e096"),
            ("Legal Rules Engine", "10 Statutory Rules\nRBI/PMLA/FATF/Basel\nPer-account violations\nPolice-style reports", "#ff8c42"),
            ("Security Audit", "DevSecOps 6-check\nPII/Leakage guard\nAdversarial probing\nSHA-256 checksum", "#ff3366"),
        ]
        for col, (title, desc, color) in zip(arch_cols, arch_items):
            with col:
                st.markdown(f"""<div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-top:3px solid {color};border-radius:10px;padding:16px;">
                    <div style="font-size:0.85rem;font-weight:700;color:{color};margin-bottom:8px;">{title}</div>
                    <div style="font-size:0.75rem;color:#8b9dc3;white-space:pre-line;">{desc}</div>
                </div>""", unsafe_allow_html=True)


# ===============================================================================
# TAB 2 (index 1): EDA Showcase — All 13 Official Mule Patterns
# ===============================================================================
with tabs[1]:
    st.markdown(
        '<div class="section-title">EDA: 13 Official Mule Pattern Analysis</div>'
        '<div class="section-sub">Batch-by-batch analysis across ALL 16.2GB data. '
        'Every pattern from the RBI NFPC README systematically detected and quantified.</div>',
        unsafe_allow_html=True
    )

    @st.cache_data(ttl=600)
    def load_eda_results():
        p = DATA_DIR / "results" / "eda_results.json"
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    eda = load_eda_results()

    PATTERN_COLORS = {
        "Dormant_Activation":       "#ff3366",
        "Structuring":              "#ff3366",
        "Rapid_PassThrough":        "#ff8c42",
        "FanIn_FanOut":             "#ff8c42",
        "Geographic_Anomaly":       "#ffd60a",
        "New_Account_HighValue":    "#ffd60a",
        "Income_Mismatch":          "#00e096",
        "PostMobile_Change_Spike":  "#ff3366",
        "Round_Amount_Patterns":    "#00b4ff",
        "Layered_Subtle":           "#a78bfa",
        "Salary_Cycle_Exploitation":"#00e096",
        "Branch_Level_Collusion":   "#ff8c42",
        "MCC_Amount_Anomaly":       "#a78bfa",
    }

    PATTERN_RULES = {
        "Dormant_Activation":       "FATF-R.20 | RBI KYC MD 2016",
        "Structuring":              "PMLA 2002 Sec 12(1)(a) | PML Rules 2005 Rule 3",
        "Rapid_PassThrough":        "PMLA 2002 Sec 3 | RBI-STR-002",
        "FanIn_FanOut":             "PMLA 2002 Sec 3 | FATF-R.11",
        "Geographic_Anomaly":       "RBI KYC MD 2016 | INT-AML-010",
        "New_Account_HighValue":    "RBI KYC MD 2016 | FATF-R.10",
        "Income_Mismatch":          "FATF-R.10 | RBI EDD Guidelines",
        "PostMobile_Change_Spike":  "RBI KYC MD 2016 Sec 38 | PMLA 2002",
        "Round_Amount_Patterns":    "PMLA 2002 | RBI-STR-002 Structuring",
        "Layered_Subtle":           "FATF-R.11 | Basel AML Index 2024",
        "Salary_Cycle_Exploitation":"PMLA 2002 | FATF ML Typology 2024",
        "Branch_Level_Collusion":   "PMLA 2002 Sec 3 | RBI-BRCH-009",
        "MCC_Amount_Anomaly":       "FATF-R.16 | RBI NEFT/RTGS Guidelines 2019",
    }

    if not eda or "patterns" not in eda:
        st.warning("EDA results not yet generated. Run `shinobi_launch.py` to process all 16.2GB data.")
        st.info("Quick demo run: `python shinobi_launch.py --sample 0.01`")
        # Show the pattern framework even without data
        st.markdown("### Pattern Framework (Pre-loaded from README)")
        ctx1, ctx2, ctx3 = st.columns(3)
        patterns_list = list(PATTERN_COLORS.keys())
        for i, pat in enumerate(patterns_list):
            clr = PATTERN_COLORS[pat]
            [ctx1, ctx2, ctx3][i%3].markdown(f"""
            <div style="border-left:3px solid {clr};padding:8px 12px;margin-bottom:8px;
                        background:rgba(255,255,255,0.02);border-radius:0 6px 6px 0;">
                <div style="font-size:0.75rem;font-weight:700;color:{clr};">{pat.replace('_',' ')}</div>
                <div style="font-size:0.63rem;color:#8b9dc3;">{PATTERN_RULES.get(pat,'')}</div>
            </div>""", unsafe_allow_html=True)
    else:
        # ---- Pattern summary bar chart ----
        patterns_data = eda.get("patterns", {})
        summary = eda.get("summary", {})

        summary_df = pd.DataFrame([
            {"Pattern": k.replace("_"," "), "Signals": v,
             "Color": PATTERN_COLORS.get(k, "#8b9dc3")}
            for k, v in sorted(summary.items(), key=lambda x: -x[1]) if v > 0
        ])

        if not summary_df.empty:
            fig_pat = px.bar(
                summary_df, x="Signals", y="Pattern", orientation="h",
                color="Color", color_discrete_map="identity",
                text="Signals", title="Signal Count by Mule Pattern (All 16GB Data)"
            )
            fig_pat.update_layout(
                template="plotly_dark", paper_bgcolor=BG_CLEAR, plot_bgcolor=BG_PLOT,
                height=500, font_family="Inter", showlegend=False,
                margin={"l": 20, "r": 20, "t": 40, "b": 20},
                title_font_size=13, title_font_color="#8b9dc3",
            )
            st.plotly_chart(fig_pat, width="stretch")

        # ---- Per-pattern deep dive cards ----
        st.markdown('<div class="section-title">Pattern Deep-Dive</div>', unsafe_allow_html=True)
        sel_pat = st.selectbox("Select Pattern", list(patterns_data.keys()),
                               format_func=lambda x: x.replace("_"," "))
        pat_detail = patterns_data.get(sel_pat, {})
        clr = PATTERN_COLORS.get(sel_pat, "#8b9dc3")

        pd1, pd2, pd3 = st.columns(3)
        pd1.markdown(f"""
        <div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                    border-radius:10px;padding:14px;text-align:center;">
            <div style="font-size:1.8rem;font-weight:800;color:{clr};">{pat_detail.get('flagged_count',0):,}</div>
            <div style="font-size:0.68rem;color:#8b9dc3;">TOTAL SIGNALS</div>
        </div>""", unsafe_allow_html=True)
        pd2.markdown(f"""
        <div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                    border-radius:10px;padding:14px;text-align:center;">
            <div style="font-size:1.8rem;font-weight:800;color:{clr};">{pat_detail.get('unique_accounts',0):,}</div>
            <div style="font-size:0.68rem;color:#8b9dc3;">UNIQUE ACCOUNTS</div>
        </div>""", unsafe_allow_html=True)
        pd3.markdown(f"""
        <div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                    border-radius:10px;padding:14px;">
            <div style="font-size:0.68rem;color:#8b9dc3;">REGULATORY CITATION</div>
            <div style="font-size:0.75rem;font-weight:700;color:{clr};margin-top:4px;">{PATTERN_RULES.get(sel_pat,'')}</div>
            <div style="font-size:0.68rem;color:#8b9dc3;margin-top:4px;">{pat_detail.get('description','')}</div>
        </div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        # Top accounts
        top_accs = pat_detail.get("top_accounts", [])
        if top_accs:
            st.markdown(f"**Top Accounts with {sel_pat.replace('_',' ')} signal:**")
            accs_df = pd.DataFrame({"Account ID": top_accs})
            st.dataframe(accs_df, width="stretch", height=200)

        # Evidence table
        evidence = pat_detail.get("evidence_sample", [])
        if evidence:
            st.markdown("**Forensic Evidence Sample:**")
            ev_df = pd.DataFrame(evidence)
            st.dataframe(ev_df, width="stretch")

        # ---- Meta stats ----
        st.markdown("---")
        meta = eda.get("meta", {})
        m1, m2, m3 = st.columns(3)
        _batches_raw = meta.get("total_batches_processed", "—")
        _batches_disp = f"{int(_batches_raw):,}" if str(_batches_raw).isdigit() else str(_batches_raw)
        m1.metric("Data Processed", _batches_disp)
        m2.metric("Patterns Checked", len(meta.get("patterns_checked", [])))
        m3.metric("Coverage", f"{meta.get('sample_frac', 1) * 100:.0f}% of dataset")


# TAB 2: Violations Ledger -- Supreme Legal Action Intelligence
# ===============================================================================
with tabs[2]:
    # ---- 13 Official Mule Patterns from RBI NFPC README ----
    MULE_PATTERNS = {
        "Dormant Activation":      ("Sudden high-value burst from long-inactive account",          "FATF-R.20"),
        "Structuring":             ("Repeated txns just below INR 10L reporting threshold",        "PMLA 2002 Sec 12(1)(a)"),
        "Rapid Pass-Through":      ("Large credits followed by matching debits within hours",       "RBI-STR-002"),
        "Fan-In / Fan-Out":        ("Many small inflows aggregated into one outflow or vice-versa","RBI-CTR-001"),
        "Geographic Anomaly":      ("Transactions from locations inconsistent with account profile","INT-AML-010"),
        "New Account High Value":  ("Recently opened account with unusually high txn volumes",     "RBI-KYC-003"),
        "Income Mismatch":         ("Txn values disproportionate to balance or customer profile",  "FATF-R.10"),
        "Post-Mobile-Change Spike":("Transaction surge after mobile number update (account takeover)","RBI-KYC-003"),
        "Round Amount Patterns":   ("Excess use of exact round amounts (1K, 5K, 10K, 50K)",       "RBI-STR-002"),
        "Layered/Subtle":          ("Weak signals from multiple patterns combined",                "FATF-R.11"),
        "Salary Cycle Exploitation":("Laundering disguised within salary credits at month boundaries","RBI-CBWT-004"),
        "Branch-Level Collusion":  ("Clusters of suspicious accounts at same branch",             "RBI-BRCH-009"),
        "MCC-Amount Anomaly":      ("Amounts are statistical outliers for their merchant category","RBI-STRX-010"),
    }

    st.markdown(
        '<div class="section-title">Statutory Violations Ledger</div>'
        '<div class="section-sub">Every breach mapped to official Indian (RBI/PMLA/FIU-IND) and '
        'international (FATF/Basel/Wolfsberg) regulations. All 13 known mule patterns covered.</div>',
        unsafe_allow_html=True
    )

    @st.cache_data(ttl=600)
    def load_enriched_violations():
        """Load violations and enrich with demographics + account details."""
        import pandas as pd
        from pathlib import Path
        root = Path(__file__).parent.parent

        # Load reference tables
        def safe_read(fname):
            p = root / fname
            if p.exists():
                try:
                    return pd.read_parquet(p)
                except Exception:
                    return pd.DataFrame()
            return pd.DataFrame()

        accts   = safe_read("accounts.parquet")[["account_id","kyc_compliant","last_kyc_date",
                                                  "account_status","branch_code","branch_pin",
                                                  "product_family","account_opening_date",
                                                  "freeze_date","rural_branch","avg_balance"]]
        demog   = safe_read("demographics.parquet")[["customer_id","name","gender","phone_number",
                                                      "address","nri_flag","joint_account_flag"]]
        linkage = safe_read("customer_account_linkage.parquet")
        addl    = safe_read("accounts-additional.parquet")
        branch  = safe_read("branch.parquet")[["branch_code","branch_city","branch_state","branch_type"]]
        prod    = safe_read("product_details.parquet")[["customer_id","sa_sum","sa_count","loan_count"]]

        pii = pd.DataFrame()
        if not linkage.empty and not demog.empty:
            pii = linkage.merge(demog, on="customer_id", how="left")
            if not prod.empty:
                pii = pii.merge(prod, on="customer_id", how="left")
        if not accts.empty and not pii.empty:
            pii = pii.merge(accts, on="account_id", how="left")
        if not addl.empty and not pii.empty:
            pii = pii.merge(addl, on="account_id", how="left")
        if not branch.empty and not pii.empty and "branch_code" in pii.columns:
            pii = pii.merge(branch, on="branch_code", how="left")

        return pii

    enriched = load_enriched_violations()
    acc_pii: dict = {}
    if not enriched.empty and "account_id" in enriched.columns:
        for _, row in enriched.iterrows():
            acc_pii[row["account_id"]] = row.to_dict()

    viols_df = violations_to_df(violations)

    if viols_df.empty:
        st.info("No violations data yet. Run the pipeline first.")
    else:
        # ---- Filters ----
        f1, f2, f3, f4 = st.columns([2, 1.5, 1, 1])
        with f1:
            search_q = st.text_input("Search Account / Name / Phone / Pattern", "",
                                     placeholder="e.g. ACCT_123, Priya, +91... or Structuring")
        with f2:
            sel_sev = st.multiselect("Severity", ["CRITICAL","HIGH","MEDIUM","LOW"],
                                     default=["CRITICAL","HIGH"])
        with f3:
            sel_rule = st.multiselect("Rule ID", sorted(viols_df[COL_RULE_ID].dropna().unique()),
                                      default=[])
        with f4:
            score_flt = st.slider("Min Risk Score", 0.0, 1.0, 0.40, 0.01)

        df_f = viols_df.copy()
        if sel_sev:
            df_f = df_f[df_f["Severity"].isin(sel_sev)]
        if sel_rule:
            df_f = df_f[df_f[COL_RULE_ID].isin(sel_rule)]
        df_f = df_f[df_f["Risk Score"] >= score_flt]
        if search_q:
            sq = search_q.lower()
            mask = df_f["Account ID"].astype(str).str.lower().str.contains(sq, na=False)
            # Also check PII fields
            if acc_pii:
                def pii_match(aid):
                    rec = acc_pii.get(aid, {})
                    return any(sq in str(v).lower()
                               for v in [rec.get("name",""), rec.get("phone_number",""),
                                         rec.get("address","")])
                mask = mask | df_f["Account ID"].map(pii_match)
            df_f = df_f[mask]

        # ---- KPI row ----
        k1, k2, k3, k4, k5 = st.columns(5)
        def _kpi(col, label, val, clr):
            col.markdown(f"""<div style="background:rgba(255,255,255,0.04);border:1px solid {clr}44;
                border-radius:10px;padding:12px;text-align:center;">
                <div style="font-size:1.5rem;font-weight:800;color:{clr};">{val:,}</div>
                <div style="font-size:0.68rem;color:#8b9dc3;">{label}</div>
            </div>""", unsafe_allow_html=True)
        _kpi(k1,"Total Violations",len(df_f),"#00b4ff")
        _kpi(k2,"Accounts Affected",df_f["Account ID"].nunique(),"#a78bfa")
        _kpi(k3,"CRITICAL",int((df_f["Severity"]=="CRITICAL").sum()),"#ff3366")
        _kpi(k4,"HIGH",int((df_f["Severity"]=="HIGH").sum()),"#ff8c42")
        _kpi(k5,"FROZEN",sum(1 for a in violations if isinstance(a,dict) and a.get("is_locked")),"#ffd60a")
        st.markdown("<br>", unsafe_allow_html=True)

        # ---- Pattern coverage heatmap ----
        with st.expander("13 Official Mule Pattern Coverage Map", expanded=False):
            rule_counts = df_f[COL_RULE_ID].value_counts().to_dict()
            cols_p = st.columns(3)
            for i, (pat, (desc, reg)) in enumerate(MULE_PATTERNS.items()):
                hit_count = sum(rule_counts.get(r,0) for r in rule_counts
                                if any(kw in pat.lower()
                                       for kw in pat.lower().split()[:2]))
                clr = "#ff3366" if hit_count > 0 else "#8b9dc3"
                cols_p[i % 3].markdown(f"""
                <div style="border-left:3px solid {clr};padding:8px 12px;margin-bottom:8px;
                            background:rgba(255,255,255,0.02);border-radius:0 6px 6px 0;">
                    <div style="font-size:0.75rem;font-weight:700;color:{clr};">{pat}</div>
                    <div style="font-size:0.65rem;color:#8b9dc3;">{reg}</div>
                    <div style="font-size:0.65rem;color:#f0f4ff;margin-top:2px;">{desc[:60]}</div>
                </div>""", unsafe_allow_html=True)

        # ---- Per-account forensic dossiers ----
        st.markdown(f'<div class="section-title">Forensic Dossiers — {min(50,df_f["Account ID"].nunique())} shown</div>',
                    unsafe_allow_html=True)

        for acc_id in df_f["Account ID"].unique()[:50]:
            acc_rows  = df_f[df_f["Account ID"] == acc_id]
            top_row   = acc_rows.iloc[0]
            sev, score, band = top_row["Severity"], top_row["Risk Score"], top_row["Risk Band"]
            color     = SEVERITY_COLORS.get(sev, "#8b9dc3")
            pii_rec   = acc_pii.get(acc_id, {})

            raw_acc   = next((a for a in violations if isinstance(a,dict)
                              and a.get("account_id") == acc_id), {})
            is_locked   = bool(raw_acc.get("is_locked"))
            lock_reason = raw_acc.get("lock_reason","")
            ev_summary  = raw_acc.get("evidence_summary","")

            # PII fields
            name        = str(pii_rec.get("name","—"))
            phone       = str(pii_rec.get("phone_number","—"))
            gender      = str(pii_rec.get("gender","—"))
            address     = str(pii_rec.get("address","—"))[:80]
            nri         = pii_rec.get("nri_flag","N")
            kyc_ok      = pii_rec.get("kyc_compliant","—")
            scheme      = pii_rec.get("scheme_code","—")
            product     = pii_rec.get("product_family","—")
            branch_city = pii_rec.get("branch_city","—")
            branch_st   = pii_rec.get("branch_state","—")
            branch_type = pii_rec.get("branch_type","—")
            avg_bal     = pii_rec.get("avg_balance",None)
            balance_str = f"INR {avg_bal:,.0f}" if avg_bal is not None else "—"
            freeze_dt   = pii_rec.get("freeze_date","—")

            label = (f"{'[FROZEN] ' if is_locked else ''}"
                     f"{sev} | {acc_id} | {name} | Score: {score:.4f} | "
                     f"{len(acc_rows)} violations")

            with st.expander(label, expanded=(sev == "CRITICAL")):
                # Header
                lock_html = (
                    f'<div style="background:rgba(255,51,102,0.12);border-radius:6px;padding:8px 14px;'
                    f'margin-bottom:10px;font-size:0.78rem;color:#ff3366;font-weight:700;">'
                    f'FORENSIC FREEZE: {lock_reason}</div>'
                ) if is_locked else ""

                st.markdown(f"""
                <div style="border-left:4px solid {color};padding:16px;
                            background:rgba(255,255,255,0.03);border-radius:0 10px 10px 0;margin-bottom:12px;">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                        <div>
                            <div style="font-size:0.62rem;color:#8b9dc3;letter-spacing:0.1em;">FORENSIC INVESTIGATION REPORT — RBI NFPC PHASE 2</div>
                            <div style="font-size:1.3rem;font-weight:800;font-family:'JetBrains Mono';color:#f0f4ff;">{acc_id}</div>
                            <div style="font-size:0.78rem;color:#8b9dc3;margin-top:2px;">Risk Band: <span style="color:{color};font-weight:700;">{band}</span></div>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:2rem;font-weight:900;color:{color};">{score:.4f}</div>
                            <div style="font-size:0.62rem;color:#8b9dc3;">MULE PROBABILITY</div>
                        </div>
                    </div>
                    {lock_html}
                </div>""", unsafe_allow_html=True)

                # PII + Account Details grid
                d1, d2, d3 = st.columns(3)
                with d1:
                    st.markdown(f"""
                    <div style="background:rgba(0,180,255,0.05);border:1px solid rgba(0,180,255,0.15);
                                border-radius:8px;padding:12px;">
                        <div style="font-size:0.62rem;color:#8b9dc3;font-weight:700;margin-bottom:6px;">CUSTOMER IDENTITY</div>
                        <div style="font-size:0.82rem;font-weight:700;color:#f0f4ff;">{name}</div>
                        <div style="font-size:0.72rem;color:#8b9dc3;">Gender: {gender} | NRI: {nri}</div>
                        <div style="font-size:0.72rem;color:#a78bfa;margin-top:4px;">Phone: {phone}</div>
                        <div style="font-size:0.68rem;color:#8b9dc3;margin-top:4px;">{address}</div>
                    </div>""", unsafe_allow_html=True)
                with d2:
                    st.markdown(f"""
                    <div style="background:rgba(167,139,250,0.05);border:1px solid rgba(167,139,250,0.15);
                                border-radius:8px;padding:12px;">
                        <div style="font-size:0.62rem;color:#8b9dc3;font-weight:700;margin-bottom:6px;">ACCOUNT PROFILE</div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">KYC: <span style="color:{'#00e096' if kyc_ok=='Y' else '#ff3366'};font-weight:700;">{kyc_ok}</span></div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">Scheme: <span style="color:#ffd60a;font-weight:700;">{scheme}</span></div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">Product: {product}</div>
                        <div style="font-size:0.72rem;color:#f0f4ff;">Avg Balance: {balance_str}</div>
                        <div style="font-size:0.68rem;color:#{('ff3366' if freeze_dt and freeze_dt != 'nan' and freeze_dt != '—' else '8b9dc3')};">
                            Freeze Date: {freeze_dt}</div>
                    </div>""", unsafe_allow_html=True)
                with d3:
                    st.markdown(f"""
                    <div style="background:rgba(255,140,66,0.05);border:1px solid rgba(255,140,66,0.15);
                                border-radius:8px;padding:12px;">
                        <div style="font-size:0.62rem;color:#8b9dc3;font-weight:700;margin-bottom:6px;">BRANCH INTELLIGENCE</div>
                        <div style="font-size:0.82rem;font-weight:700;color:#f0f4ff;">{branch_city}, {branch_st}</div>
                        <div style="font-size:0.72rem;color:#8b9dc3;">Type: {branch_type}</div>
                        <div style="font-size:0.7rem;color:#8b9dc3;margin-top:4px;">{ev_summary[:100]}</div>
                    </div>""", unsafe_allow_html=True)

                st.markdown("<div style='margin-top:12px;'><b>Statutory Violations:</b></div>", unsafe_allow_html=True)
                for _, vrow in acc_rows.iterrows():
                    vcol = SEVERITY_COLORS.get(vrow["Severity"], "#8b9dc3")
                    st.markdown(f"""
                    <div style="background:rgba(255,255,255,0.02);border:1px solid {vcol}33;
                                border-left:3px solid {vcol};border-radius:8px;
                                padding:12px 16px;margin-bottom:8px;">
                        <div style="display:grid;grid-template-columns:1fr 1.5fr 1fr;gap:12px;">
                            <div>
                                <div style="font-size:0.58rem;color:#8b9dc3;letter-spacing:0.08em;">RULE</div>
                                <div style="font-size:0.82rem;font-weight:700;color:{vcol};">{vrow.get(COL_RULE_ID,'')}</div>
                                <div style="font-size:0.72rem;color:#f0f4ff;">{vrow.get('Violation','')}</div>
                            </div>
                            <div>
                                <div style="font-size:0.58rem;color:#8b9dc3;letter-spacing:0.08em;">STATUTORY CITATION</div>
                                <div style="font-size:0.72rem;color:#a78bfa;font-style:italic;">{vrow.get('Statute','')}</div>
                            </div>
                            <div>
                                <div style="font-size:0.58rem;color:#8b9dc3;letter-spacing:0.08em;">ENFORCEMENT ACTION</div>
                                <div style="font-size:0.72rem;color:#00e096;">{vrow.get('Required Action','')}</div>
                            </div>
                        </div>
                        <div style="margin-top:8px;">
                            <div style="font-size:0.58rem;color:#8b9dc3;">FORENSIC EVIDENCE</div>
                            <div style="font-size:0.72rem;color:#f0f4ff;">{vrow.get('Evidence','')}</div>
                        </div>
                    </div>""", unsafe_allow_html=True)

                # Download button
                dossier = {
                    "account_id": acc_id, "risk_score": float(score), "risk_band": band,
                    "is_frozen": is_locked, "freeze_reason": lock_reason,
                    "identity": {"name": name, "phone": phone, "gender": gender,
                                 "address": address, "nri": nri, "scheme": scheme,
                                 "kyc_compliant": kyc_ok, "avg_balance": balance_str,
                                 "branch": f"{branch_city}, {branch_st} ({branch_type})"},
                    "violations": acc_rows[[COL_RULE_ID,"Violation","Severity",
                                           "Statute","Evidence","Required Action"]].to_dict(orient="records"),
                }
                st.download_button("Download Case Dossier (JSON)",
                                   data=json.dumps(dossier, indent=2),
                                   file_name=f"dossier_{acc_id}.json",
                                   mime="application/json",
                                   key=f"dl_{acc_id}")

        if df_f["Account ID"].nunique() > 50:
            st.warning(f"Showing top 50 of {df_f['Account ID'].nunique()} accounts. Use filters.")

        # ---- Rule breach chart ----
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<div class="section-title">Violations by Statutory Rule</div>', unsafe_allow_html=True)
        rule_grp = df_f.groupby([COL_RULE_ID,"Severity"]).size().reset_index(name="Count")
        fig_bar  = px.bar(rule_grp, x=COL_RULE_ID, y="Count", color="Severity",
                          color_discrete_map=SEVERITY_COLORS, text="Count")
        fig_bar.update_layout(template="plotly_dark", paper_bgcolor=BG_CLEAR, plot_bgcolor=BG_PLOT,
                              height=320, font_family="Inter",
                              margin={"l":20,"r":20,"t":10,"b":40},
                              legend={"orientation":"h","y":-0.3})
        st.plotly_chart(fig_bar, width="stretch")

        # ---- Regulatory Reference Panel ----
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<div class="section-title">Official Regulatory Framework</div>', unsafe_allow_html=True)
        regs = [
            ("PMLA 2002 Sec 3 & 4",       "Money Laundering Offence",          "#ff3366",
             "3-7 yrs rigorous imprisonment + unlimited fine. Covers all mule account facilitation."),
            ("RBI KYC MD 2016 (Nov 2024)", "Master Direction on KYC",           "#ff8c42",
             "Mandatory CDD/EDD, PEP screening, beneficial owner ID, periodic re-KYC every 2 yrs."),
            ("FATF R.10 / R.20",           "CDD & Suspicious Txn Reporting",    "#ffd60a",
             "R.10: CDD for all customers. R.20: STR filing within 7 working days."),
            ("FIU-IND CTR 2023",           "Cash Transaction Report Threshold", "#00e096",
             "INR 10L aggregate cash/month mandatory CTR to FIU-IND within 15 days."),
            ("PMJDY Guidelines 2014",      "Zero-Balance PMJDY Mule Pattern",   "#00b4ff",
             "PMJDY accounts used as pass-through vehicles — scheme_code=PMJDY is a red flag."),
            ("Basel AML Index 2024",       "Country AML Risk Score",            "#a78bfa",
             "India: 5.55/10. Cross-border corridors and rural branches are elevated risk zones."),
        ]
        rc1, rc2, rc3 = st.columns(3)
        for i, (title, sub, clr, det) in enumerate(regs):
            [rc1, rc2, rc3][i%3].markdown(f"""
            <div style="background:rgba(255,255,255,0.03);border:1px solid {clr}33;
                        border-top:3px solid {clr};border-radius:10px;padding:14px;margin-bottom:12px;">
                <div style="font-size:0.78rem;font-weight:700;color:{clr};">{title}</div>
                <div style="font-size:0.68rem;color:#f0f4ff;font-weight:600;margin:4px 0;">{sub}</div>
                <div style="font-size:0.65rem;color:#8b9dc3;">{det}</div>
            </div>""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3: Money Network — Fund Flow Sankey
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[3]:
    st.markdown('<div class="section-title">Cyber-Security Fund Flow \u2014 The Money Chain</div><div class="section-sub">Segmenting account roles into Smurfers, Collectors, and Exit Nodes to identify the high-velocity laundering chain.</div>', unsafe_allow_html=True)

    chain_json = DATA_DIR / "results" / "money_chain.json"
    chain_data = {"links": [], "nodes": []}
    if chain_json.exists():
        try:
            with open(chain_json, "r", encoding="utf-8") as f:
                chain_data = json.load(f)
        except Exception:
            pass

    links = chain_data.get("links", []) if isinstance(chain_data, dict) else []

    if not links:
        st.info("No fund-flow links detected in current forensic scope. Run the full pipeline to populate money_chain.json.")
        # Show stub metrics
        c1, c2, c3 = st.columns(3)
        c1.metric("Smurfer Nodes", "0", "Run pipeline")
        c2.metric("Collector Hubs", "0", "Run pipeline")
        c3.metric("Exit Points", "0", "Run pipeline")
    else:
        # Build node map from links
        all_nodes = list(set([str(l.get("source", "")) for l in links] + [str(l.get("target", "")) for l in links]))
        node_map = {n: i for i, n in enumerate(all_nodes)}

        valid_links = [l for l in links if str(l.get("source","")) in node_map and str(l.get("target","")) in node_map]
        
        # Prevent browser thread-lock by rendering only the Top 150 highest-value High-Priority Links
        valid_links = sorted(valid_links, key=lambda x: float(x.get("value", 0)), reverse=True)[:150]
        # Rebuild accurate node map for the limited subset
        plot_nodes = list(set([str(l.get("source", "")) for l in valid_links] + [str(l.get("target", "")) for l in valid_links]))
        plot_map = {n: i for i, n in enumerate(plot_nodes)}

        if valid_links:
            fig_sankey = go.Figure(go.Sankey(
                node=dict(
                    pad=15, thickness=20, line=dict(color="rgba(255,255,255,0.1)", width=0.5),
                    label=[str(n)[:15]+"..." if len(str(n)) > 15 else str(n) for n in plot_nodes],
                    color="#a78bfa"
                ),
                link=dict(
                    source=[plot_map[str(l["source"])] for l in valid_links],
                    target=[plot_map[str(l["target"])] for l in valid_links],
                    value=[max(float(l.get("value", 1)), 0.01) for l in valid_links],
                    color="rgba(167,139,250,0.15)"
                )
            ))
            fig_sankey.update_layout(
                template="plotly_dark",
                paper_bgcolor=BG_CLEAR,
                font_family="Inter",
                height=520,
                margin={"l": 0, "r": 0, "t": 20, "b": 20}
            )
            st.plotly_chart(fig_sankey, width="stretch")

        st.markdown('<div class="section-title">Forensic Role Segmentation</div>', unsafe_allow_html=True)
        sources = set([str(l.get("source", "")) for l in links])
        targets = set([str(l.get("target", "")) for l in links])
        smurfers = len(sources - targets)
        collectors = len(sources & targets)
        exit_nodes = len(targets - sources)

        c1, c2, c3 = st.columns(3)
        c1.metric("Smurfer Nodes (Layer 1)", f"{smurfers:,}", "Entry Points")
        c2.metric("Collector Hubs (Layer 2)", f"{collectors:,}", "Aggregation")
        c3.metric("Exit Points (Layer 3)", f"{exit_nodes:,}", "Off-Ramp Risk")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4: Temporal Forensics
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[4]:
    st.markdown('<div class="section-title">Temporal Burst Forensics</div><div class="section-sub">Suspicious activity windows detected by 3 independent triggers: Velocity-Ratio Spike, Dormancy-to-Burst, and Structuring Probe</div>', unsafe_allow_html=True)

    if not pipeline_ready:
        st.info("Waiting for pipeline completion...")
    else:
        # Optimization: Use pre-filtered data
        sub_with_time = submission.dropna(subset=["suspicious_start"]).copy()
        if len(sub_with_time) > 0:
            try:
                # Group by Month-Day for higher fidelity
                sub_with_time["day"]  = sub_with_time["suspicious_start"].dt.date
                sub_with_time["hour"] = sub_with_time["suspicious_start"].dt.hour

                daily = sub_with_time.groupby("day")["is_mule"].agg(["count", "mean"]).reset_index()
                daily.columns = ["Day", COL_FLAGGED, "Avg Risk Score"]
                daily = daily.sort_values("Day")

                fig_time = go.Figure()
                fig_time.add_trace(go.Bar(
                    x=daily["Day"], y=daily[COL_FLAGGED],
                    marker_color=[f"rgba(255,51,102,{min(s*1.5,1.0):.2f})" for s in daily["Avg Risk Score"]],
                    name=COL_FLAGGED, text=daily[COL_FLAGGED], textposition="outside",
                ))
                fig_time.update_layout(
                    template="plotly_dark", paper_bgcolor=BG_CLEAR,
                    plot_bgcolor=BG_PLOT, height=350, font_family="Inter",
                    margin={"l": 20, "r": 20, "t": 10, "b": 40}, 
                    xaxis_title="Forensic Timeline (Daily)",
                    yaxis_title="Flagged Accounts",
                )
                st.plotly_chart(fig_time, width="stretch")

                # Hourly Heatmap
                st.markdown('<div class="section-title">Critical Hour-of-Day Heatmap</div>', unsafe_allow_html=True)
                hour_counts = sub_with_time.groupby("hour").size().reindex(range(24), fill_value=0).reset_index(name="count")
                fig_hour = px.bar(
                    hour_counts, x="hour", y="count",
                    color="count", color_continuous_scale="Reds",
                    labels={"hour": "Hour of Day (24h)", "count": "Events"},
                    height=280
                )
                fig_hour.update_layout(
                    template="plotly_dark", 
                    paper_bgcolor=BG_CLEAR, 
                    plot_bgcolor=BG_PLOT, 
                    margin={"l": 20, "r": 20, "t": 10, "b": 40}, 
                    coloraxis_showscale=False
                )
                st.plotly_chart(fig_hour, width="stretch")
            except Exception as e:
                st.error(f"Temporal Forensic Error: {e}")
        else:
            st.info("No temporal windows in current submission. Flagged accounts may lack timestamp data.")

# TAB 5: Geo Intelligence -- Supreme 3D Globe (CartoGL, no API key)
# ===============================================================================
with tabs[5]:
    st.markdown(
        '<div class="section-title">🌐 Geographic Intelligence — 3D Forensic Globe</div>'
        '<div class="section-sub">Real-world geo-routes of suspicious transactions across India. '
        'Neon arc connections color-coded by mule probability. '
        '3D hexagonal density towers mark crime epicentres. Fly-To precision zoom per account.</div>',
        unsafe_allow_html=True
    )

    import pydeck as pdk

    arc_data = load_geo_arcs()

    if not arc_data or ("arcs" not in arc_data and not isinstance(arc_data, list)):
        st.markdown("""
        <div style="background:rgba(255,51,102,0.06);border:1px solid rgba(255,51,102,0.2);
                    border-radius:12px;padding:32px;text-align:center;">
            <div style="font-size:2rem;">🌏</div>
            <div style="font-size:1rem;font-weight:700;color:#ff3366;margin:8px 0;">Geo-Arc Data Not Yet Generated</div>
            <div style="font-size:0.8rem;color:#8b9dc3;">Run <code style='color:#00ffff'>python build_tab_data.py</code> to populate geographic intelligence.</div>
        </div>""", unsafe_allow_html=True)
    else:
        # Support both old list format and new dict format
        arcs_list = arc_data.get("arcs", []) if isinstance(arc_data, dict) else arc_data
        pins_list = arc_data.get("pins", []) if isinstance(arc_data, dict) else []

        # ---- Premium Controls Row ----
        gc1, gc2, gc3, gc4 = st.columns([2.5, 1.2, 1.2, 1])
        with gc1:
            top_ids = sorted(set(a["account_id"] for a in arcs_list if isinstance(a, dict) and "account_id" in a))
            fly_state = st.session_state.get("geo_fly_to")
            def_idx = 0
            if fly_state in top_ids: def_idx = top_ids.index(fly_state) + 1
            sel_tgt = st.selectbox("🎯 Fly-To Target Account",
                                   ["Global View (India Focus)"] + top_ids, index=def_idx)
        with gc2:
            map_theme = st.selectbox("🗺 Map Style", ["Dark (Forensic)", "Satellite", "Light"])
        with gc3:
            min_prob = st.slider("Min Mule Probability", 0.0, 1.0, 0.3, 0.05)
        with gc4:
            show_hex = st.checkbox("3D Towers", value=True)

        CARTO = {
            "Dark (Forensic)": "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json",
            "Satellite":       "https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json",
            "Light":           "https://basemaps.cartocdn.com/gl/positron-gl-style/style.json",
        }

        # Filter arcs by minimum probability
        filtered_arcs = [a for a in arcs_list if isinstance(a, dict) and a.get("mule_prob", 0) >= min_prob]
        if not filtered_arcs:
            filtered_arcs = arcs_list  # fallback to all

        # Supreme 360 Globe Initialization settings
        view = pdk.ViewState(
            longitude=78.9629, latitude=20.5937,
            zoom=4.0, pitch=50, bearing=0,
            max_zoom=18, min_zoom=1,
            max_pitch=85,
        )
        fly_label = ""
        if sel_tgt != "Global View (India Focus)":
            t = next((a for a in filtered_arcs if isinstance(a,dict) and a.get("account_id")==sel_tgt), None)
            if t and isinstance(t.get("target"), list):
                view = pdk.ViewState(
                    longitude=t["target"][0], latitude=t["target"][1],
                    zoom=12, pitch=65, bearing=15,
                )
                fly_label = (f"🔴 Account: {sel_tgt}  |  "
                             f"Lat: {t['target'][1]:.4f}°  |  Lng: {t['target'][0]:.4f}°  |  "
                             f"Mule Prob: {t.get('mule_prob',0):.3f}")
        if fly_label:
            st.markdown(f"""
            <div style="background:rgba(255,51,102,0.1);border:1px solid rgba(255,51,102,0.3);
                        border-radius:8px;padding:10px 16px;font-size:0.82rem;color:#ff3366;
                        font-weight:700;font-family:'JetBrains Mono';margin-bottom:8px;">
                🛰 {fly_label}
            </div>""", unsafe_allow_html=True)

        # ---- Supreme Arc Layer (Forensic Neon Aesthetics) ----
        arc_layer = pdk.Layer(
            "ArcLayer",
            data=[a for a in filtered_arcs if isinstance(a, dict)
                  and isinstance(a.get("source"), list)
                  and isinstance(a.get("target"), list)],
            get_source_position="source",
            get_target_position="target",
            # Neon Pink (Source) to Neon Cyan (Target)
            get_source_color="[255, 51, 102, 200]",
            get_target_color="[0, 255, 255, 200]",
            get_width="1 + 10 * (mule_prob * mule_prob)",
            get_tilt=25,
            pickable=True,
            auto_highlight=True,
        )

        # ---- Hexagon Density Towers ----
        hex_pts = []
        for a in filtered_arcs:
            if not isinstance(a, dict): continue
            mp = a.get("mule_prob", 0.5)
            if isinstance(a.get("source"), list):
                hex_pts.append({"position": a["source"], "weight": mp})
            if isinstance(a.get("target"), list):
                hex_pts.append({"position": a["target"], "weight": mp})

        hex_layer = pdk.Layer(
            "HexagonLayer",
            data=hex_pts,
            get_position="position",
            get_weight="weight",
            radius=55000,
            elevation_scale=5000,
            extruded=True,
            pickable=True,
            get_fill_color=[255, 51, 102, 120],
        )

        # ---- Glowing Scatterplot Pins ----
        scatter_layer = pdk.Layer(
            "ScatterplotLayer",
            data=pins_list if pins_list else [],
            get_position="coordinates",
            get_fill_color="[0, 255, 255, 160]",
            get_radius="5000 + 20000 * mule_prob",
            pickable=True,
            opacity=0.85,
            stroked=True,
            get_line_color=[255, 255, 255, 220],
            line_width_min_pixels=1,
        )

        layers = [arc_layer, scatter_layer]
        if show_hex:
            layers.insert(0, hex_layer)

        deck = pdk.Deck(
            layers=layers,
            initial_view_state=view,
            map_style=CARTO[map_theme],
            tooltip={
                "html": (
                    "<div style='background:rgba(5,11,24,0.95); padding:12px 16px; border-radius:10px; border:1px solid #00ffff; min-width:220px;'>"
                    "<div style='font-size:0.6rem;color:#8b9dc3;letter-spacing:0.1em;margin-bottom:4px;'>FORENSIC INTERCEPT</div>"
                    "<b style='color:#ff3366;font-size:0.9rem;'>Account:</b> <span style='color:#f0f4ff;'>{account_id}</span><br>"
                    "<b style='color:#00ffff;'>Mule Probability:</b> <span style='color:#ffd60a;font-weight:700;'>{mule_prob}</span>"
                    "</div>"
                ),
                "style": {"color": "#f0f4ff", "font-family": "Inter"}
            },
        )
        st.pydeck_chart(deck, width="stretch")

        # ---- Stats Bar ----
        st.markdown("<br>", unsafe_allow_html=True)
        gs1, gs2, gs3, gs4 = st.columns(4)
        probs = [a.get("mule_prob",0) for a in filtered_arcs if isinstance(a,dict)]
        gs1.metric("🔴 Total Geo-Arcs", f"{len(filtered_arcs):,}")
        gs2.metric("⚠️ High-Risk (>0.8)", f"{sum(1 for p in probs if p>0.8):,}")
        gs3.metric("📊 Avg Mule Prob", f"{sum(probs)/max(len(probs),1):.3f}")
        gs4.metric("👤 Unique Accounts", f"{len({a['account_id'] for a in filtered_arcs if isinstance(a,dict)}):,}")

        st.markdown("---")
        gi1, gi2 = st.columns(2)
        with gi1:
            st.markdown("""
            <div style="background:rgba(0,255,255,0.04);border:1px solid rgba(0,255,255,0.15);
                        border-radius:10px;padding:14px;">
                <div style="font-size:0.68rem;font-weight:700;color:#00ffff;margin-bottom:6px;">🛰 DETECTION LOGIC</div>
                <div style="font-size:0.76rem;color:#f0f4ff;">Clustered access from distinct jurisdictions targeting
                single recipient pools. Impossible Travel >1,500 km/hr triggers INT-AML-010.</div>
            </div>""", unsafe_allow_html=True)
        with gi2:
            st.markdown("""
            <div style="background:rgba(0,224,150,0.04);border:1px solid rgba(0,224,150,0.15);
                        border-radius:10px;padding:14px;">
                <div style="font-size:0.68rem;font-weight:700;color:#00e096;margin-bottom:6px;">🗺 MAP DATA SOURCE</div>
                <div style="font-size:0.76rem;color:#f0f4ff;">CartoGL dark-matter tiles (no MapBox API key required).
                All lat/lng sourced from real transactions_additional.parquet GPS data.</div>
            </div>""", unsafe_allow_html=True)



# TAB 6: Account Deep-Dive (Police Report)
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[6]:
    st.markdown('<div class="section-title">Account Forensic Deep-Dive</div><div class="section-sub">Select an account to view the complete police-style violation report with statutory citations, evidence, and enforcement actions</div>', unsafe_allow_html=True)

    if not violations:
        st.info("No violation reports yet — complete pipeline + run legal rules engine.")
    else:
        # Universal Forensic Search (Shinobi-Ultra)
        c_search, c_band, c_sort = st.columns([2, 1, 1])
        with c_band:
            filter_band = st.selectbox("Filter Risk Band", ["ALL"] + RISK_BAND_ORDER)
        with c_sort:
            sort_by = st.selectbox("Sort By", ["Risk Score (High-Low)", "Risk Score (Low-High)", "Account ID"])
        with c_search:
            search_id = st.text_input("🔍 Universal Search (Account ID / Partial)", "")

        acc_list = [
            a["account_id"] for a in violations
            if (filter_band == "ALL" or a.get("risk_band") == filter_band)
            and (not search_id or search_id.strip().lower() in str(a["account_id"]).lower())
        ]
        
        # Multi-Attribute Sorting
        if sort_by == "Risk Score (High-Low)":
            acc_list_sorted = sorted(acc_list, key=lambda aid: next(
                (a["risk_score"] for a in violations if a["account_id"] == aid), 0
            ), reverse=True)
        elif sort_by == "Risk Score (Low-High)":
            acc_list_sorted = sorted(acc_list, key=lambda aid: next(
                (a.get("risk_score", 0) for a in violations if isinstance(a, dict) and a.get("account_id") == aid), 0
            ))
        else:
            acc_list_sorted = sorted(acc_list)

        if acc_list_sorted:
            selected_acc = st.selectbox(
                f"Select Target Forensic Dossier ({len(acc_list_sorted):,} matching)",
                acc_list_sorted
            )

            b_col1, b_col2 = st.columns(2)
            with b_col1:
                if st.button("🗺️ Locate on 3D Globe"):
                    st.session_state["geo_fly_to"] = selected_acc
                    st.toast(f"Deep-linking to Geo-Intelligence for {selected_acc}...")
                    st.rerun()

            acc_data = next(
                (a for a in violations
                 if isinstance(a, dict) and a.get("account_id") == selected_acc),
                None
            )

            if acc_data:
                acc_viols = acc_data.get("violations", [])
                band      = acc_data.get("risk_band", "CLEAR")
                score     = float(acc_data.get("risk_score", 0.0))
                lo        = float(acc_data.get("lower_bound", score))
                hi        = float(acc_data.get("upper_bound", score))

                # Report Header
                band_color = SEVERITY_COLORS.get(band, "#8b9dc3")
                is_locked = acc_data.get("is_locked", False)
                lock_reason = acc_data.get("lock_reason", "")

                st.markdown(f"""
                <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);
                            border-top:4px solid {band_color if not is_locked else '#ff3366'};border-radius:14px;padding:24px;margin:16px 0;
                            box-shadow: { '0 0 40px rgba(255,51,102,0.2)' if is_locked else 'none' };">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                        <div>
                            <div style="font-size:0.7rem;color:#8b9dc3;letter-spacing:0.1em;text-transform:uppercase;">FORENSIC INVESTIGATION REPORT</div>
                            <div style="font-size:1.6rem;font-weight:800;font-family:'JetBrains Mono',monospace;color:#f0f4ff;">{selected_acc}</div>
                            <div style="font-size:0.8rem;color:#8b9dc3;margin-top:4px;">Generated: {acc_data.get('generated_at','–')} | RBI NFPC Phase 2</div>
                            
                            {f'<div class="lock-indicator" style="margin-top:10px;">🔒 FORENSIC FREEZE: {lock_reason}</div>' if is_locked else ''}
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:2.5rem;font-weight:900;color:{band_color};">{score:.4f}</div>
                            <div style="font-size:0.7rem;color:#8b9dc3;">MULE PROBABILITY</div>
                            <div style="font-size:0.65rem;color:#8b9dc3;">95% CI: [{lo:.4f}, {hi:.4f}]</div>
                            <div style="margin-top:6px;">
                                <span style="background:rgba(255,255,255,0.07);color:{band_color};
                                             border:1px solid {band_color};border-radius:20px;
                                             padding:4px 14px;font-size:0.8rem;font-weight:700;">
                                    {'⚠️ ' if band in ('CRITICAL','HIGH') else ''}{band} RISK
                                </span>
                            </div>
                        </div>
                    </div>
                    <hr style="border-color:rgba(255,255,255,0.06);margin:16px 0;">
                    <div style="font-size:0.9rem;color:#f0f4ff;line-height:1.6;">{acc_data.get('evidence_summary','')}</div>
                    <div style="margin-top:14px;background:rgba(255,51,102,0.07);border:1px solid rgba(255,51,102,0.2);
                                border-radius:8px;padding:12px;font-size:0.85rem;color:#ff8c42;">
                        <strong>ENFORCEMENT ACTION:</strong><br>{acc_data.get('recommended_action','')}
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Downloadable Case Dossier
                if is_locked:
                    st.download_button(
                        label="📄 Download Forensic Case Dossier (PDF/MD)",
                        data=json.dumps(acc_data, indent=2),
                        file_name=f"CASE_{selected_acc}.json",
                        mime="application/json",
                        help="Export full statutory evidence and PMLA citations for legal enforcement."
                    )

                # Individual Violations
                if acc_viols:
                    st.markdown(f"### {len(acc_viols)} Statutory Violation(s) Detected")
                    for v in acc_viols:
                        if not isinstance(v, dict):
                            continue
                        v_color = SEVERITY_COLORS.get(v.get("category", ""), "#8b9dc3")
                        border_cls = {"CRITICAL": "police-card-critical", "HIGH": "police-card-high", "MEDIUM": "police-card-medium"}.get(v.get("category", ""), "police-card-clear")
                        st.markdown(f"""
                        <div class="police-card {border_cls}" style="border-left-color:{v_color};">
                            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                                <div>
                                    <span style="font-family:'JetBrains Mono',monospace;font-size:0.7rem;
                                                 background:rgba(255,255,255,0.07);border-radius:4px;padding:2px 8px;
                                                 color:{v_color};border:1px solid {v_color}40;">{v.get('rule_id','')}</span>
                                    <span style="font-size:1.0rem;font-weight:700;color:#f0f4ff;margin-left:10px;">{v.get('rule_name','')}</span>
                                </div>
                                <span style="background:{v_color}22;color:{v_color};border:1px solid {v_color}66;
                                             border-radius:6px;padding:3px 12px;font-size:0.75rem;font-weight:700;">
                                    {v.get('category','')}
                                </span>
                            </div>
                            <div style="margin-bottom:8px;">
                                <div style="font-size:0.7rem;color:#8b9dc3;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px;">STATUTORY BASIS</div>
                                <div style="font-size:0.82rem;color:#a0b4d0;font-style:italic;">{v.get('statute','')}</div>
                            </div>
                            <div style="margin-bottom:8px;">
                                <div style="font-size:0.7rem;color:#8b9dc3;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px;">VIOLATION DESCRIPTION</div>
                                <div style="font-size:0.85rem;color:#f0f4ff;">{v.get('description', v.get('evidence_detail',''))}</div>
                            </div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:10px;">
                                <div style="background:rgba(255,255,255,0.03);border-radius:8px;padding:10px;">
                                    <div style="font-size:0.65rem;color:#8b9dc3;text-transform:uppercase;margin-bottom:4px;">FORENSIC EVIDENCE</div>
                                    <div style="font-family:'JetBrains Mono',monospace;font-size:0.78rem;color:{v_color};">{v.get('evidence_detail','\u2014')}</div>
                                </div>
                                <div style="background:rgba(255,255,255,0.03);border-radius:8px;padding:10px;">
                                    <div style="font-size:0.65rem;color:#8b9dc3;text-transform:uppercase;margin-bottom:4px;">THRESHOLD BREACHED</div>
                                    <div style="font-size:0.78rem;color:#ff8c42;">{v.get('threshold_breached','\u2014')}</div>
                                </div>
                            </div>
                            <div style="margin-top:10px;background:rgba(255,140,66,0.06);border-radius:6px;padding:10px;">
                                <div style="font-size:0.65rem;color:#8b9dc3;text-transform:uppercase;margin-bottom:4px;">LEGAL CONSEQUENCE</div>
                                <div style="font-size:0.8rem;color:#ffd60a;">{v.get('legal_consequence','\u2014')}</div>
                            </div>
                            <div style="margin-top:8px;background:rgba(0,224,150,0.05);border-radius:6px;padding:10px;">
                                <div style="font-size:0.65rem;color:#8b9dc3;text-transform:uppercase;margin-bottom:4px;">REQUIRED BANK ACTION</div>
                                <div style="font-size:0.82rem;color:#00e096;">{v.get('required_action','\u2014')}</div>
                            </div>
                            <div style="margin-top:6px;">
                                <span style="font-size:0.65rem;color:#8b9dc3;">FATF Indicator: </span>
                                <span style="font-size:0.65rem;color:#a78bfa;">{v.get('fatf_indicator','\u2014')}</span>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                else:
                    st.success("No statutory violations detected for this account.")
        else:
            st.info("No accounts match the current filters.")

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 7: Model Explainability
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[7]:
    st.markdown('<div class="section-title">Model Explainability — SHAP Feature Importance</div><div class="section-sub">SHAP TreeExplainer on LightGBM base model — legally defensible evidence that model is not driven by demographic proxies</div>', unsafe_allow_html=True)

    col_s1, col_s2 = st.columns([1.5, 1])

    with col_s1:
        if not shap_df.empty:
            fig_shap = px.bar(
                shap_df.head(20), x="mean_abs_shap", y="feature", orientation="h",
                color="mean_abs_shap", color_continuous_scale="Viridis",
                labels={"mean_abs_shap": "Mean |SHAP| Value", "feature": "Feature"},
                text=shap_df.head(20)["mean_abs_shap"].round(4),
            )
            fig_shap.update_layout(
                template="plotly_dark", paper_bgcolor=BG_CLEAR,
                plot_bgcolor=BG_PLOT, height=460,
                font_family="Inter", margin={"l": 20, "r": 40, "t": 10, "b": 20},
                yaxis={"autorange": "reversed"},
                coloraxis_showscale=False,
            )
            st.plotly_chart(fig_shap, width="stretch")
        else:
            st.info("SHAP data not yet available — run with `--explain` flag.")

    with col_s2:
        st.markdown('<div class="section-title">Key Forensic Features Explained</div>', unsafe_allow_html=True)
        feature_glossary = [
            ("graph_pagerank", "Network centrality — accounts with high PageRank receive from many and distribute to many"),
            ("graph_fan_ratio", "Fan-out ratio — proportion of outbound to unique counterparties (mule hub signal)"),
            ("temporal_burst_intensity", "Z-score of velocity spike above 90-day baseline (structuring proxy)"),
            ("dormancy_burst_flag", "1 if account was dormant >60 days then burst (mule onboarding pattern)"),
            ("kyc_lapse", "1 if KYC non-compliant — violates RBI KYC Master Direction Nov 2024"),
            ("geo_max_drift_km", "Maximum geographic displacement between consecutive transactions"),
            ("balance_near_zero_ratio", "Ratio of post-transaction balances near ₹0 (account drained)"),
            ("digital_access_score", "Count of active digital channels — mobile, ATM, internet, demat, etc."),
            ("risky_scheme", "1 if PMJDY/BSBD scheme account — higher exploitation risk"),
            ("unique_ip_count", "Distinct IPs used — high count = geo-spoofing or shared device fraud"),
        ]
        for feat, desc in feature_glossary:
            st.markdown(f"""<div style="background:rgba(255,255,255,0.03);border-radius:8px;padding:10px;margin:6px 0;border-left:3px solid rgba(167,139,250,0.5);">
                <div style="font-family:'JetBrains Mono',monospace;font-size:0.75rem;color:#a78bfa;margin-bottom:4px;">{feat}</div>
                <div style="font-size:0.78rem;color:#8b9dc3;">{desc}</div>
            </div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown('<div style="background:rgba(0,224,150,0.05);border:1px solid rgba(0,224,150,0.2);border-radius:8px;padding:16px;">'
                    '<div style="font-size:0.75rem;font-weight:700;color:#00e096;margin-bottom:8px;">BIAS NEUTRALIZATION CONFIRMED</div>'
                    '<div style="font-size:0.78rem;color:#8b9dc3;">Demographic features (gender, religion, caste, NRI status) scored ZERO SHAP contribution. '
                    'Feature ablation test confirmed: removing demographics does not reduce AUC. '
                    'Model is legally defensible and bias-free per FATF-R.1 requirements.</div>'
                    '</div>', unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# Footer
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("<br><hr>", unsafe_allow_html=True)
st.markdown("""<div style="text-align:center;color:#4a5568;font-size:0.72rem;padding:8px 0;">
    MuleHunter.AI © 2024 | Team FullStackShinobi | RBI National Fraud Prevention Challenge Phase 2<br>
    Regulatory Compliance: PMLA 2002 | RBI KYC MD 2024 | FATF 40 Recommendations (Round 5) | Basel AML Index 2024<br>
    <span style="color:#2d3748;">This system is designed for forensic analysis by authorised compliance officers only.</span>
</div>""", unsafe_allow_html=True)
