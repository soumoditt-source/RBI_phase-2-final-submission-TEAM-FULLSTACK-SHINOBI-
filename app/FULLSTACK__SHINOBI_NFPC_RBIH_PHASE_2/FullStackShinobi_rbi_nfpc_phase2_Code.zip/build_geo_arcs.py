"""
build_geo_arcs.py — Supreme Geo-Spatial Extraction
===================================================
Extracts the maximum feasible number of geo arcs (2000 routes) for the 3D globe,
using real transactions_additional.parquet GPS telemetry from the 16.2GB dataset.
"""
import sys
import logging
from pathlib import Path
from src.data.geo_analyzer import extract_top_arcs

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("Shinobi.GeoBuilder")

def main():
    log.info("=" * 60)
    log.info("🗺️ BUILDING SUPREME 3D GEO-INTELLIGENCE ARCS")
    log.info("=" * 60)
    
    ROOT = Path(__file__).parent.resolve()
    submission_path = ROOT / "submission.csv"
    output_path = ROOT / "results" / "geo_arcs.json"
    
    if not submission_path.exists():
        log.error("submission.csv not found! Run inference first.")
        sys.exit(1)
        
    extract_top_arcs(
        ROOT=ROOT,
        submission_path=submission_path,
        output_path=output_path,
        top_n=2000  # Massively scaled up from 200 for impressive 16GB display
    )
    
    log.info(f"✅ Extracted maximum safe volume (2000 arcs) to {output_path.name}")

if __name__ == "__main__":
    main()
