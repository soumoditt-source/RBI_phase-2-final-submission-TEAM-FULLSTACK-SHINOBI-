import zipfile
import sys
import collections

zip_path = '11_OUT_OF_10_FINAL.zip'
print(f'Checking {zip_path} against RBI Rules...')

if not zipfile.is_zipfile(zip_path):
    print('❌ ERROR: Not a valid ZIP file!')
    sys.exit(1)

allowed_exts = {'.py', '.ipynb', '.r', '.sh', '.bat', '.json', '.yaml', '.yml', '.toml', '.cfg', '.ini', '.txt', '.md', '.pkl', '.joblib', '.pt', '.pth', '.onnx', '.h5'}
prohibited_exts = {'.parquet', '.csv', '.hdf5', '.npy', '.npz', '.feather'}

uncompressed_size = 0
has_readme = False
ext_counts = collections.Counter()
violations = []

with zipfile.ZipFile(zip_path, 'r') as zf:
    for info in zf.infolist():
        if info.is_dir(): continue
        uncompressed_size += info.file_size
        filename = info.filename
        
        # Check for README in root
        if '/' not in filename and '\\' not in filename:
            if filename.lower() in ('readme.md', 'readme.txt'):
                has_readme = True

        idx = filename.rfind('.')
        ext = filename[idx:].lower() if idx != -1 else ''
        ext_counts[ext] += 1
        
        if ext in prohibited_exts:
            violations.append(f'PROHIBITED extension {ext}: {filename}')
        elif ext and ext not in allowed_exts:
            violations.append(f'UNALLOWED extension {ext}: {filename}')

print('\n--- ZIP AUDIT REPORT ---')
size_mb = uncompressed_size / (1024 * 1024)
print(f'Total Uncompressed Size: {size_mb:.2f} MB (Limit: 200 MB)')
if size_mb > 200:
    print('❌ ERROR: Exceeds 200 MB limit!')

print(f'Root README exists: {has_readme}')
if not has_readme:
    print('❌ ERROR: Missing README.md in root!')

print('\nFile Extensions contained:')
for ext, count in ext_counts.items():
    print(f'  {ext}: {count} files')

if violations:
    print('\n❌ RULE VIOLATIONS FOUND:')
    for v in violations:
        print(f'  - {v}')
else:
    print('\n✅ ZERO RULE VIOLATIONS. COMPLIANCE 100%')
