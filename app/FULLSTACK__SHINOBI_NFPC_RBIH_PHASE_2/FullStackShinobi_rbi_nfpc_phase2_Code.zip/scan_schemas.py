"""Schema discovery script — reads every parquet on disk and writes a JSON summary."""
import pandas as pd, os, glob, json, sys

DATA = r'd:\RBI NFPC PHASE 2'
result = {}

small = [
    'accounts.parquet','accounts-additional.parquet','customers.parquet',
    'customer_account_linkage.parquet','demographics.parquet',
    'branch.parquet','product_details.parquet',
    'train_labels.parquet','test_accounts.parquet'
]
for fname in small:
    fp = os.path.join(DATA, fname)
    if os.path.exists(fp):
        try:
            df = pd.read_parquet(fp, engine='pyarrow')
            result[fname] = {
                'rows': int(len(df)),
                'cols': list(df.columns),
                'dtypes': {c: str(t) for c, t in df.dtypes.items()},
                'null_pct': {c: round(float(df[c].isnull().mean()*100),2) for c in df.columns}
            }
        except Exception as e:
            result[fname] = {'error': str(e)}

txn_parts  = sorted(glob.glob(os.path.join(DATA, 'transactions', '**', '*.parquet'), recursive=True))
txna_parts = sorted(glob.glob(os.path.join(DATA, 'transactions_additional', '**', '*.parquet'), recursive=True))
result['_meta'] = {'txn_parts': len(txn_parts), 'txna_parts': len(txna_parts)}

if txn_parts:
    try:
        df_t = pd.read_parquet(txn_parts[0], engine='pyarrow')
        result['_txn_schema'] = {
            'source': txn_parts[0],
            'rows_in_part': int(len(df_t)),
            'cols': list(df_t.columns),
            'dtypes': {c: str(t) for c, t in df_t.dtypes.items()},
            'sample': df_t.head(3).to_dict(orient='records')
        }
    except Exception as e:
        result['_txn_schema'] = {'error': str(e)}

if txna_parts:
    try:
        df_ta = pd.read_parquet(txna_parts[0], engine='pyarrow')
        result['_txna_schema'] = {
            'source': txna_parts[0],
            'rows_in_part': int(len(df_ta)),
            'cols': list(df_ta.columns),
            'dtypes': {c: str(t) for c, t in df_ta.dtypes.items()},
            'sample': df_ta.head(3).to_dict(orient='records')
        }
    except Exception as e:
        result['_txna_schema'] = {'error': str(e)}

out_path = os.path.join(DATA, 'schema_discovery.json')
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, default=str)
print(f"Wrote {out_path}")
print(json.dumps(result, indent=2, default=str))
