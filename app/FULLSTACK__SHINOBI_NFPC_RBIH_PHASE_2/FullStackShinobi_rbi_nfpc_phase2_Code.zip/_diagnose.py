"""Quick diagnostic — what data do each tab's data files contain?"""
import json, pandas as pd
from pathlib import Path
root = Path("d:/RBI NFPC PHASE 2")

def show(label, obj, depth=2):
    print(f"\n=== {label} ===")
    if isinstance(obj, list):
        print(f"  list length: {len(obj)}")
        if obj:
            first = obj[0]
            print(f"  first type: {type(first).__name__}")
            if isinstance(first, dict):
                print(f"  first keys: {list(first.keys())}")
                print(f"  first item: {str(first)[:400]}")
    elif isinstance(obj, dict):
        print(f"  keys: {list(obj.keys())}")
        for k, v in list(obj.items())[:5]:
            if isinstance(v, list):
                print(f"  {k}: [{len(v)} items]", str(v[0])[:100] if v else "[]")
            else:
                print(f"  {k}: {str(v)[:100]}")
    else:
        print(f"  {type(obj).__name__}: {str(obj)[:200]}")

# Submission
sub = pd.read_csv(root / "submission.csv")
print("=== SUBMISSION ===")
print("  shape:", sub.shape, "cols:", list(sub.columns))
print("  suspicious_start non-null:", sub["suspicious_start"].notna().sum())
print("  is_mule min/max:", sub["is_mule"].min(), "/", sub["is_mule"].max())
suspicious = sub[sub["suspicious_start"].notna()]
print("  rows with suspicious_start:", len(suspicious))

# Geo arcs
ga = json.load(open(root / "results" / "geo_arcs.json"))
show("GEO_ARCS", ga)

# Violations
av = json.load(open(root / "results" / "account_violations.json"))
show("ACCOUNT_VIOLATIONS", av)

# Money chain
mc = json.load(open(root / "results" / "money_chain.json"))
show("MONEY_CHAIN", mc)

# Audit report
ar = json.load(open(root / "results" / "audit_report.json"))
show("AUDIT_REPORT", ar)

# SHAP
for p in list(root.rglob("*shap*")) + list(root.rglob("*importance*")):
    if p.suffix in (".csv", ".json"):
        print(f"\nFOUND: {p}")

# Final features schema
import pyarrow.parquet as pq
pf = pq.read_schema(root / "results" / "final_features.parquet")
print("\n=== FINAL_FEATURES schema ===")
for name in pf.names:
    print(f"  {name}")
