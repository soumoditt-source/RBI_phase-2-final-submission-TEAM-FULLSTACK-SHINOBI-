from __future__ import annotations

import os
import subprocess
import sys
import logging
import webbrowser
import shutil
import time
from pathlib import Path

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("NFPC.Launcher")

DATA_DIR      = Path(__file__).parent
SUBMISSION    = DATA_DIR / "submission.csv"
VIOLATIONS    = DATA_DIR / "account_violations.json"

BANNER = r"""
╔══════════════════════════════════════════════════════════════════╗
║         MuleHunter.AI — Forensic Intelligence Platform          ║
║         RBI National Fraud Prevention Challenge Phase 2         ║
║         Team: FullStackShinobi                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""

def run(cmd: list[str], desc: str) -> int:
    log.info(">>> %s", desc)
    result = subprocess.run(cmd, cwd=str(DATA_DIR))
    if result.returncode != 0:
        log.error("FAILED: " + desc + " (exit " + str(result.returncode) + ")")
    return result.returncode

def verify_system_integrity():
    log.info("🔍 Performing System Integrity Verification (10/10 Check)...")
    checks = [
        ("Pipeline Core", DATA_DIR / "run_all.py"),
        ("Legal Engine", DATA_DIR / "src" / "validation" / "legal_rules_engine.py"),
        ("Graph Network", DATA_DIR / "src" / "features" / "graph_network.py"),
        ("Dashboard UI", DATA_DIR / "app" / "dashboard.py"),
    ]
    all_green = True
    for name, path in checks:
        if path.exists():
            log.info("  [PASS] " + name + " verified.")
        else:
            log.error("  [FAIL] " + name + " missing at " + str(path))
            all_green = False
    
    if all_green:
        log.info("✅ ALL SYSTEMS GREEN. Integrity 100%. Quality Grade: TOP.")
    return all_green

import argparse

def _args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="MuleHunter.AI Master Launcher")
    p.add_argument("--fast", action="store_true", help="Launch in Shinobi-Fast 2-min demo mode")
    p.add_argument("--sample", type=float, default=1.0, help="Data sample fraction (default 1.0)")
    return p.parse_args()

def auto_install_deps():
    log.info("📦 Checking System Dependencies...")
    # Map of {import_name: package_name}
    required = {
        "numpy": "numpy",
        "pandas": "pandas",
        "pyarrow": "pyarrow",
        "pydeck": "pydeck",
        "xgboost": "xgboost",
        "lightgbm": "lightgbm",
        "streamlit": "streamlit",
        "networkx": "networkx",
        "rustworkx": "rustworkx",
        "polars": "polars",
        "sklearn": "scikit-learn",
        "shap": "shap",
        "scipy": "scipy"
    }
    import importlib.util
    missing_pkgs = []
    for imp, pkg in required.items():
        if importlib.util.find_spec(imp) is None:
            missing_pkgs.append(pkg)
    
    if missing_pkgs:
        log.warning(f"Missing dependencies detected: {missing_pkgs}. Auto-installing...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", *missing_pkgs], check=True)
            log.info("✅ Dependencies synced.")
        except Exception as e:
            log.error(f"Failed to install dependencies: {e}")

def main() -> None:
    args = _args()
    print(BANNER)
    
    auto_install_deps()

    
    if not verify_system_integrity():
        log.critical("System corrupted or files missing. Fix and re-run.")
        sys.exit(1)

    # ── Step 1: Run pipeline ──────────────────────────────────────────────────
    # If --fast is set, run_all.py will skip sharding if shards exist.
    pipeline_args = [sys.executable, "run_all.py", "--sample", str(args.sample), "--audit", "--explain"]
    if args.fast:
        pipeline_args.append("--fast")
        log.info("🚀 SHINOBI-FAST MODE ENABLED. Aiming for < 2-min execution.")

    rc = run(pipeline_args, "Ultimate 16GB Forensic Pipeline")
    if rc != 0:
        log.critical("Pipeline failed. Fix and re-run.")
        sys.exit(1)

    # ── Step 1b: Optional Feature Cache Bypass ────────────────────────────────
    # If using --fast and cache exists, we can jump straight to UI in future calls.
    FEATS_CACHE = DATA_DIR / "notebooks" / "features_cache.parquet"
    if args.fast and FEATS_CACHE.exists():
        log.info("🚀 SHINOBI-BOOST: Feature cache secured. Showcase ready.")

    # ── Step 2: Generate legal violations report ───────────────────────────────
    log.info("⚖️  Mapping ML Signals to Statutory Violations (RBI/PMLA/FATF)...")
    rule_script = f"""
import sys, pandas as pd
sys.path.insert(0, r'{DATA_DIR}')
from src.validation.legal_rules_engine import LegalRulesEngine
from pathlib import Path

DATA = Path(r'{DATA_DIR}')
log_path = DATA / 'account_violations.json'
sub = pd.read_csv(DATA / 'submission.csv')
feat_path = DATA / 'notebooks' / 'features_cache.parquet'

if not feat_path.exists():
    print("CRITICAL: Feature cache missing. Run processing first.")
    sys.exit(1)

feats = pd.read_parquet(feat_path)
engine = LegalRulesEngine()
reports = engine.generate_reports(feats, sub, log_path)
print("SUCCESS: Generated " + str(len(reports)) + " Forensic Violation Reports")
"""
    run([sys.executable, "-c", rule_script], "Forensic Legal Rules Engine")

    # ── Step 2.5: Generate 3D Globe Telemetry (geo_arcs.json) ──────────────────
    log.info("🛰️  Generating 3D Geolocation Telemetry for the Forensic Globe...")
    rc_geo = run([sys.executable, "src/data/geo_analyzer.py"], "Geo-Spatial Telemetry Engine")
    if rc_geo != 0:
        log.warning("Geo-Telemetry failed. The 3D globe may lack arcs, but pipeline continues.")

    # ── Step 3: Launch Dashboard ───────────────────────────────────────────────
    log.info("🚀 LAUNCHING INTERACTIVE FORENSIC DASHBOARD...")
    log.info("=" * 65)
    log.info("  MuleHunter.AI Live URL: http://localhost:8501")
    log.info("  Terminal Status: STREAMING ANALYSIS")
    log.info("=" * 65)

    # Launch streamlit in background-like mode and open browser
    log.info("🚀 OPENING DASHBOARD...")
    
    # Wait a tiny bit for the server to bind
    def open_link():
        time.sleep(2)
        webbrowser.open("http://localhost:8501")
    
    import threading
    threading.Thread(target=open_link, daemon=True).start()

    subprocess.run([
        sys.executable, "-m", "streamlit", "run", "app/dashboard.py",
        "--server.port", "8501",
        "--theme.base", "dark",
        "--browser.gatherUsageStats", "false",
        "--server.headless", "true"
    ], cwd=str(DATA_DIR))

    # ── Step 4: Archive Final Submission ──────────────────────────────────────
    FINAL_DIR = DATA_DIR / "final_submission_bundle"
    FINAL_DIR.mkdir(exist_ok=True)
    
    files_to_copy = [
        SUBMISSION, 
        VIOLATIONS, 
        DATA_DIR / "model_explainability.json",
        DATA_DIR / "notebooks" / "features_cache.parquet"
    ]
    
    log.info("📦 UNIFYING RESULTS INTO %s...", FINAL_DIR.name)
    for f in files_to_copy:
        if f.exists():
            shutil.copy2(f, FINAL_DIR / f.name)
            
    log.info("🏆 SUBMISSION BUNDLE COMPLETE. PHASE 2 VICTORY.")

if __name__ == "__main__":
    main()
