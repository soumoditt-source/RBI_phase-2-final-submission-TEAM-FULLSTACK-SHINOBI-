# MuleHunter.AI — NFPC Phase 2 Submission

**Team:** FullStackShinobi  
**Challenge:** National Fraud Prevention Challenge (NFPC) — Organized by RBI Innovation Hub & IIT Delhi  
**Approach:** Hybrid HFT Feature Engineering + 7-Model ML Ensemble + Graph PageRank Centrality

---

## Environment Setup

**Python Version:** 3.10+

```bash
# Create virtual environment
python -m venv .venv
.venv\Scripts\activate  # Windows

# Install all dependencies
pip install -r requirements.txt
```

**Key Dependencies:**

- `polars>=0.19.0` — Memory-safe streaming for 16.2GB dataset
- `scikit-learn`, `xgboost`, `lightgbm` — ML ensemble
- `rustworkx` — PageRank graph centrality
- `streamlit`, `plotly`, `pydeck` — Forensic visualization dashboard

---

## How to Reproduce Results

### Step 1: One-Click Supreme Launch (Recommended)

```bash
python supreme_winner_launch.py
```

This orchestrates the entire pipeline:

1. Dependency installation
2. HFT Feature Engineering (Map-Reduce across 16.2GB)
3. ML Ensemble Training (XGBoost + LightGBM + Random Forest)
4. Geo-Arc + Money Chain generation
5. Streamlit Dashboard launch

### Step 2: Individual Stage Control

```bash
# HFT Feature Engineering only
python -m src.features.hft_engine

# Model training and submission generation
python -m src.models.train_and_infer

# Dashboard data preparation
python build_tab_data.py

# Dashboard launch
streamlit run app/dashboard.py
```

---

## Approach Summary

### 1. HFT Feature Engineering (114+ Features)

A Map-Reduce pattern processes 16.2GB across 396 partitions without memory crashes:

- **Structuring Density:** Detects transactions clustering below INR 50,000 (PMLA threshold)
- **Temporal Burst:** Dormancy-to-velocity transitions detected via IQR change-point analysis
- **AML Channel Ratios:** UPI/CASH/IMPS diversity, round-amount density, counterparty entropy
- **Geospatial Signals:** GPS-based impossible travel detection (>1,500 km/hr)
- **PII Linkage:** Shared name/phone/address clustering ("phantom family" pattern)
- **KYC Compliance Lapse:** KYC expiry signals factored into risk scoring
- **Cross-Interaction Features:** 55 non-linear feature interaction terms

### 2. ML Ensemble (7-Model Stack)

- XGBoost (primary), LightGBM, HistGradientBoostingClassifier, Random Forest, ExtraTree, Logistic Regression, Neural MLP
- SMOTE-NC oversampling to address extreme class imbalance (~1% mule rate)
- Venn-Abers probability calibration for reliable confidence bounds
- Stratified 5-fold cross-validation; mean AUC: ~0.74

### 3. Network Graph (Rustworkx PageRank)

Identifies MULE_HUB accounts using PageRank centrality over illicit transaction flows:

- Smurfer (Layer 1) → Collector (Layer 2) → Exit Node (Layer 3) topology

### 4. Temporal IoU

Dormancy change-point detection assigns `suspicious_start` and `suspicious_end` windows for each flagged mule account, enabling the Temporal IoU bonus metric scoring.

---

## Red-Herring Avoidance Strategy

The 16.2GB dataset contains known red-herring traps:

- **Salary-Cycle Decoys:** Filtered by irregular burst pattern vs regular salary cadence
- **NRI Off-shore Flags:** Modeled separately as supplementary risk adjustment (not primary signal)
- **Festival Spending Bursts:** Excluded via seasonal calendar masking
- **Ghost Precursor Bursts:** Ignored via minimum 14-day rolling window filter

SHAP analysis confirms zero demographic bias (gender/age/NRI flags have negligible SHAP values).

---

## Submission File Format

```
submission.csv columns: account_id, is_mule, suspicious_start, suspicious_end
```

- `is_mule`: Calibrated probability (0.00–1.00)
- `suspicious_start`: ISO timestamp of detected suspicious activity onset
- `suspicious_end`: ISO timestamp of detected suspicious activity cessation
- Test accounts without detected suspicious windows have null `suspicious_start`/`suspicious_end`

---

## External Resources

None. All models are trained from scratch on the provided dataset.
