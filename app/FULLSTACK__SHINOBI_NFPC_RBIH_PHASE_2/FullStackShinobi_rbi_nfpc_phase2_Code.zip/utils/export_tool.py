"""
Shinobi-Cortex: Multimodal Export Utility
==========================================
Enables high-speed conversion of forensic results to any requested format.
"""

import logging
import os
from pathlib import Path
import pandas as pd
import polars as pl

log = logging.getLogger("NFPC.Export")

class ExportTool:
    """
    Universal converter: Parquet -> CSV, JSON, SQLite, Excel.
    """

    @staticmethod
    def to_any(source_path: str, target_format: str = "csv"):
        """Convert a Parquet result to the specified format."""
        src = Path(source_path)
        if not src.exists():
            log.error(f"Source file not found: {source_path}")
            return

        log.info(f"Converting {src.name} to {target_format.upper()}...")
        
        # Load with Polars for speed
        df = pl.read_parquet(src)

        target_path = src.with_suffix(f".{target_format}")
        
        if target_format == "csv":
            df.write_csv(target_path)
        elif target_format == "json":
            df.write_json(target_path)
        elif target_format == "sqlite":
            import sqlite3
            conn = sqlite3.connect(src.with_suffix(".db"))
            df.to_pandas().to_sql("forensics", conn, if_exists="replace")
            conn.close()
        elif target_format == "excel":
            # Requires xlsxwriter
            df.to_pandas().to_excel(target_path, index=False)
        else:
            log.error(f"Unsupported format: {target_format}")
            return

        log.info(f"Successfully exported to: {target_path}")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    # Example: Export the feature cache
    ExportTool.to_any("features_cache.parquet", "csv")
