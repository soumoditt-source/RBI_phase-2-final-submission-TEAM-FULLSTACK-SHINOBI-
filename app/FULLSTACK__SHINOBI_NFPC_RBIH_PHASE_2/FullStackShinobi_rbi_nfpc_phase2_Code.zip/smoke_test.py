"""
Comprehensive smoke-test for every module before the 100% run.
Run: python smoke_test.py
"""
import sys, os, traceback, logging, time
logging.basicConfig(format="%(asctime)s [%(levelname)s] %(name)s — %(message)s", level=logging.INFO)
log = logging.getLogger("SMOKE")
DATA = r"d:\RBI NFPC PHASE 2"

PASS, FAIL = [], []

def run(name, fn):
    try:
        t = time.perf_counter()
        result = fn()
        log.info("[PASS] %s - OK in %.1fs. %s", name, time.perf_counter()-t, result or "")
        PASS.append(name)
    except Exception as e:
        log.error("[FAIL] %s - FAILED: %s", name, e)
        traceback.print_exc()
        FAIL.append((name, str(e)))

# ── Test 1: All 9 reference tables load ──────────────────────────────────────
def test_reference_tables():
    import pandas as pd
    tables = [
        "accounts.parquet","accounts-additional.parquet","customers.parquet",
        "customer_account_linkage.parquet","branch.parquet","product_details.parquet",
        "demographics.parquet","train_labels.parquet","test_accounts.parquet"
    ]
    for t in tables:
        df = pd.read_parquet(os.path.join(DATA, t), engine="pyarrow")
        assert len(df) > 0, f"Empty: {t}"
    return "9/9 reference tables loaded"

run("Reference Tables", test_reference_tables)

# ── Test 2: schema_config imports ────────────────────────────────────────────
def test_schema_config():
    from src.data.schema_config import (
        TRANSACTION_DTYPES, ACCOUNT_DERIVED_DTYPES,
        LEAKY_COLUMNS, PII_COLUMNS, DROP_BEFORE_FEATURES
    )
    assert "freeze_date" in LEAKY_COLUMNS
    assert "name" in PII_COLUMNS
    return f"LEAKY={len(LEAKY_COLUMNS)} PII={len(PII_COLUMNS)}"

run("Schema Config", test_schema_config)

# ── Test 3: pipeline.py — relational integrity check ─────────────────────────
def test_pipeline():
    from src.data.pipeline import DataPipeline
    p = DataPipeline(DATA)
    acc = p.load_accounts()
    assert len(acc) == 160153, f"Expected 160153 accounts, got {len(acc)}"
    master = p.build_account_master(split="train")
    assert "freeze_date" not in master.columns, "freeze_date leaked into master!"
    assert "name" not in master.columns, "PII 'name' leaked into master!"
    return f"master={master.shape}"

run("Pipeline + Leakage Guard", test_pipeline)

# ── Test 4: First transaction chunk read + integrity ─────────────────────────
def test_first_chunk():
    from src.data.pipeline import DataPipeline
    p = DataPipeline(DATA)
    for chunk in p.stream_validated_transactions(chunk_rows=1_000_000, sample_frac=0.005):
        assert "account_id" in chunk.columns
        assert "amount" in chunk.columns
        assert "transaction_timestamp" in chunk.columns
        assert "counterparty_id" in chunk.columns
        has_valid = chunk["account_id"].isin(p.load_accounts()["account_id"]).all()
        return f"rows={len(chunk)}, all_valid_accounts={has_valid}"
    return "no chunks"

run("Transaction Chunk + Relational Integrity", test_first_chunk)

# ── Test 5: transactions_additional first part ───────────────────────────────
def test_txna():
    import glob, pandas as pd
    parts = sorted(glob.glob(os.path.join(DATA, "transactions_additional", "**", "*.parquet"), recursive=True))
    assert len(parts) == 311, f"Expected 311 txna parts, got {len(parts)}"
    df = pd.read_parquet(parts[0], engine="pyarrow")
    for col in ["transaction_id","latitude","longitude","ip_address","balance_after_transaction"]:
        assert col in df.columns, f"Missing col: {col}"
    return f"311 parts valid, sample={len(df)}"

run("Transactions-Additional Schema", test_txna)

# ── Test 6: graph_network.py smoke ────────────────────────────────────────────
def test_graph():
    from src.features.graph_network import GraphFeatureExtractor
    import pandas as pd, numpy as np
    rng = np.random.default_rng(0)
    n   = 2000
    ts  = pd.to_datetime(["2024-01-01"] * n)
    df  = pd.DataFrame({
        "account_id":             [f"A{i%50}" for i in range(n)],
        "counterparty_id":        [f"CP{rng.integers(0,200)}" for _ in range(n)],
        "amount":                 rng.exponential(5000, n).astype("float32"),
        "txn_type":               rng.choice(["C","D"], n),
        "transaction_timestamp":  ts,
    })
    g = GraphFeatureExtractor()
    g.build_graph(df)
    feats = g.extract_features()
    assert "graph_pagerank" in feats.columns
    assert "graph_fan_ratio" in feats.columns
    return f"graph_feats={feats.shape}"

run("Graph Feature Extractor", test_graph)

# ── Test 7: temporal_burst.py smoke ──────────────────────────────────────────
def test_temporal():
    from src.features.temporal_burst import TemporalBurstEngine
    import pandas as pd, numpy as np
    rng = np.random.default_rng(1)
    n   = 3000
    df  = pd.DataFrame({
        "account_id":            [f"A{i%30}" for i in range(n)],
        "transaction_timestamp": pd.date_range("2023-01-01", periods=n, freq="3h"),
        "amount":                rng.exponential(8000, n).astype("float32"),
        "txn_type":              rng.choice(["C","D"], n),
        "counterparty_id":       [f"CP{rng.integers(0,100)}" for _ in range(n)],
    })
    eng = TemporalBurstEngine()
    feats = eng.extract_features(df)
    assert "suspicious_start" in feats.columns
    assert "temporal_burst_intensity" in feats.columns
    return f"temporal_feats={feats.shape}"

run("Temporal Burst Engine", test_temporal)

# ── Test 8: spatial_geo.py contextual ─────────────────────────────────────────
def test_spatial():
    from src.features.spatial_geo import SpatialFeatureExtractor
    from src.data.pipeline import DataPipeline
    p = DataPipeline(DATA)
    master = p.build_account_master(split="train")
    ext = SpatialFeatureExtractor()
    ctx = ext.extract_contextual_features(master)
    assert "kyc_lapse" in ctx.columns
    assert "digital_access_score" in ctx.columns
    return f"ctx_feats={ctx.shape}"

run("Spatial / Contextual Features", test_spatial)

# ── Test 9: security_audit.py ────────────────────────────────────────────────
def test_security():
    from src.validation.security_audit import SecurityAudit
    import pandas as pd, numpy as np
    rng = np.random.default_rng(2)
    n   = 500
    df_ok = pd.DataFrame({
        "account_id":           [f"A{i}" for i in range(n)],
        "graph_pagerank":       rng.uniform(0,1,n).astype("float32"),
        "temporal_burst_intensity": rng.exponential(1,n).astype("float32"),
        "is_mule":              rng.choice([0,1], n, p=[0.99,0.01]),
    })
    a = SecurityAudit()
    r = a.run(df_ok, is_training=True)
    assert r["passed"], "Clean audit should pass"
    # PII injection must block
    df_bad = df_ok.copy()
    df_bad["name"] = "Test User"
    df_bad["freeze_date"] = "2024-01-01"
    try:
        a2 = SecurityAudit()
        a2.run(df_bad, is_training=True)
        return "ERROR: PII should have been blocked"
    except RuntimeError:
        return "clean=PASS | PII=BLOCKED [OK]"

run("Security Audit (clean + PII injection)", test_security)

# ── Test 10: ensemble smoke ────────────────────────────────────────────────────
def test_ensemble():
    from src.models.ensemble import MuleEnsemble
    import pandas as pd, numpy as np
    rng = np.random.default_rng(3)
    n   = 3000
    X   = pd.DataFrame({
        "graph_pagerank":      rng.uniform(0,1,n).astype("float32"),
        "temporal_burst":      rng.exponential(1.5,n).astype("float32"),
        "geo_drift":           rng.uniform(0,200,n).astype("float32"),
        "kyc_lapse":           rng.choice([0,1],n,p=[0.9,0.1]).astype("int8"),
        "digital_access_score":rng.integers(0,6,n).astype("int8"),
    })
    y = pd.Series(rng.choice([0,1], n, p=[0.97,0.03]).astype(int))
    ens = MuleEnsemble(n_folds=2)
    ens.fit(X, y)
    preds = ens.predict(X.head(5))
    assert "score" in preds.columns
    assert "lower_bound" in preds.columns
    return f"preds.shape={preds.shape} | score_range=[{preds['score'].min():.3f},{preds['score'].max():.3f}]"

run("Ensemble (LightGBM+XGBoost+Logistic)", test_ensemble)

# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "="*60)
print(f"SMOKE TEST RESULTS: {len(PASS)} PASSED | {len(FAIL)} FAILED")
print("="*60)
if FAIL:
    for name, err in FAIL:
        print(f"  [FAIL] {name}: {err}")
    print("\nFix above errors before running 100%.")
    sys.exit(1)
else:
    print("  [ALL PASS] ALL TESTS PASSED - SAFE TO RUN 100%")
    print("  Run: python run_all.py --sample 1.0 --audit --explain")
    sys.exit(0)
