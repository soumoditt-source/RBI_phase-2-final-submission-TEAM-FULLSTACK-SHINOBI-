"""
DEFINITIVE Money Chain Builder — Pure Polars (No rustworkx dependency for links)
==================================================================================
1. Loads HFT features to rank accounts by computed forensic risk score.
2. Scans ALL b1_part_*.parquet transaction partitions.
3. Aggregates account→counterparty edges with total INR volume and txn count.
4. Assigns roles (MULE_HUB / COLLECTOR / SMURFER) by in-degree + out-degree score.
5. Writes results/money_chain.json with correct {nodes, links}.

Run: python rebuild_money_chain_v3.py
"""
import json, glob, logging
from pathlib import Path
import polars as pl, pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("MoneyChainV3")

ROOT   = Path(__file__).parent
RESULTS = ROOT / "results"
MAX_PARQUET_ROWS = 5_000_000   # safety cap (approx 50 partitions of ~100k rows each)
TOP_HUBS = 150                 # Number of hub nodes to feature
MAX_LINKS = 500                # Cap for browser performance


def run():
    log.info("=" * 65)
    log.info("  MONEY CHAIN BUILDER V3  —  Pure Polars Mode")
    log.info("=" * 65)

    # ── Step 1: Load HFT-derived risk proxy ─────────────────────────────
    hft_path = RESULTS / "hft_features.parquet"
    if not hft_path.exists():
        log.error("Missing hft_features.parquet — run HFT engine first.")
        return

    hft = pd.read_parquet(hft_path, columns=[
        "account_id", "hft_total_volume", "hft_structuring_count",
        "hft_credit_vol", "hft_debit_vol", "hft_round_density",
        "hft_structuring_density",
    ])
    hft["account_id"] = hft["account_id"].astype(str)
    hft["risk_score"] = (
        hft["hft_structuring_density"].fillna(0) * 50 +
        hft["hft_round_density"].fillna(0) * 30 +
        (hft["hft_credit_vol"].fillna(0) / (hft["hft_total_volume"].fillna(1) + 1)) * 100
    )

    # All account IDs sorted by risk — top 6k are our suspicious pool
    top_risk_ids = set(hft.nlargest(6000, "risk_score")["account_id"].tolist())
    log.info(f"Suspicious account pool: {len(top_risk_ids)} accounts")

    # Submission scores
    scores: dict[str, float] = {}
    sub_path = ROOT / "submission.csv"
    if sub_path.exists():
        sub = pd.read_csv(sub_path, usecols=["account_id", "is_mule"])
        sub["account_id"] = sub["account_id"].astype(str)
        scores = dict(zip(sub["account_id"], sub["is_mule"]))
        sub_hi = set(sub[sub["is_mule"] > 0.25]["account_id"].tolist())
        top_risk_ids |= sub_hi
        log.info(f"  Extended pool (+submission signals): {len(top_risk_ids)}")

    hft_risk = dict(zip(hft["account_id"], hft["risk_score"]))

    # ── Step 2: Scan all transaction partitions ──────────────────────────
    parquet_files = sorted(glob.glob(str(RESULTS / "b1_part_*.parquet")))
    log.info(f"Scanning {len(parquet_files)} b1_part_*.parquet partitions...")

    top_ids_list = list(top_risk_ids)
    chunks: list[pl.DataFrame] = []
    total_rows = 0

    for pf in parquet_files:
        if total_rows >= MAX_PARQUET_ROWS:
            break
        try:
            df = pl.read_parquet(pf, columns=["account_id", "counterparty_id", "amount"])
            filtered = df.filter(pl.col("account_id").is_in(top_ids_list))
            if len(filtered) > 0:
                chunks.append(filtered)
                total_rows += len(filtered)
        except Exception as e:
            log.warning(f"  skip {Path(pf).name}: {e}")

    if not chunks:
        log.error("Zero edges found. Check partition paths.")
        return

    all_edges_pl = pl.concat(chunks)
    log.info(f"Raw edges loaded: {len(all_edges_pl):,} rows (across all high-risk accounts)")

    # ── Step 3: Aggregate → unique source→target pairs ──────────────────
    edge_agg = (
        all_edges_pl
        .group_by(["account_id", "counterparty_id"])
        .agg([
            pl.col("amount").abs().sum().alias("vol"),
            pl.len().alias("cnt"),
        ])
        .sort("vol", descending=True)
        .to_pandas()
    )
    edge_agg["account_id"]      = edge_agg["account_id"].astype(str)
    edge_agg["counterparty_id"] = edge_agg["counterparty_id"].astype(str)
    log.info(f"Unique account→counterparty pairs: {len(edge_agg):,}")

    # ── Step 4: Compute hub scores (out-degree INR vol) ──────────────────
    # Hub score = total OUT volume + total IN volume (both sides of flow)
    out_vol = edge_agg.groupby("account_id")["vol"].sum().rename("out_vol")
    in_vol  = edge_agg.groupby("counterparty_id")["vol"].sum().rename("in_vol")
    hub_df  = pd.concat([out_vol, in_vol], axis=1).fillna(0)
    hub_df["hub_score"]  = hub_df["out_vol"] + hub_df["in_vol"] * 0.5
    hub_df["out_degree"] = edge_agg.groupby("account_id")["cnt"].sum()
    hub_df["in_degree"]  = edge_agg.groupby("counterparty_id")["cnt"].sum()
    hub_df = hub_df.fillna(0)

    # Top hub accounts
    top_hubs_df = hub_df.nlargest(TOP_HUBS, "hub_score")
    top_hub_set = set(top_hubs_df.index.astype(str).tolist())
    log.info(f"Top {len(top_hub_set)} hubs identified by flow volume")

    # ── Step 5: Build nodes ───────────────────────────────────────────────
    max_hub_score = top_hubs_df["hub_score"].max() + 1e-9
    nodes: list[dict] = []
    for acc in top_hub_set:
        hs = float(hub_df.loc[acc, "hub_score"] if acc in hub_df.index else 0)
        pct = hs / max_hub_score * 100
        od  = int(hub_df.loc[acc, "out_degree"] if acc in hub_df.index else 0)
        id_ = int(hub_df.loc[acc, "in_degree"]  if acc in hub_df.index else 0)

        if pct > 12:
            role, color = "MULE_HUB",  "#ff3366"
        elif pct > 4:
            role, color = "COLLECTOR", "#ff8c42"
        else:
            role, color = "SMURFER",   "#ffd60a"

        nodes.append({
            "id":        acc,
            "label":     f"[{role}] {acc[:9]}",
            "role":      role,
            "score":     round(float(scores.get(acc, hft_risk.get(acc, 0.45) / 10)), 4),
            "size":      max(10, min(60, int(pct * 2.5 + 10))),
            "color":     color,
            "pagerank":  round(pct, 4),
            "out_txns":  od,
            "in_txns":   id_,
        })

    # ── Step 6: Build links ───────────────────────────────────────────────
    # Keep only edges where source is a top hub
    links_df = edge_agg[edge_agg["account_id"].isin(top_hub_set)].copy()
    links_df = links_df.sort_values("vol", ascending=False).head(MAX_LINKS)
    links: list[dict] = []

    leaf_nodes: set[str] = set()
    for _, row in links_df.iterrows():
        src = str(row["account_id"])
        tgt = str(row["counterparty_id"])
        links.append({
            "source": src,
            "target": tgt,
            "value":  round(float(row["vol"]) / 1_000_000, 4),   # INR millions
            "count":  int(row["cnt"]),
        })
        if tgt not in top_hub_set:
            leaf_nodes.add(tgt)

    log.info(f"Links generated: {len(links):,}")

    # Add leaf target nodes
    for tgt in leaf_nodes:
        nodes.append({
            "id":       tgt,
            "label":    f"[LEAF] {tgt[:9]}",
            "role":     "LEAF",
            "score":    round(float(scores.get(tgt, 0.15)), 4),
            "size":     8,
            "color":    "#8b9dc3",
            "pagerank": 0,
        })

    log.info(f"Total nodes (hubs + leaves): {len(nodes):,}")

    # ── Step 7: Write output ──────────────────────────────────────────────
    output = {
        "nodes": nodes,
        "links": links,
        "meta": {
            "partitions_scanned":   len(parquet_files),
            "suspicious_pool_size": len(top_risk_ids),
            "unique_edges":         len(edge_agg),
            "hubs_detected":        len(top_hub_set),
            "links_written":        len(links),
        }
    }

    out_file = RESULTS / "money_chain.json"
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, default=str)

    log.info(f"\n{'='*65}")
    log.info(f"  ✅  SAVED:  {out_file}")
    log.info(f"      Nodes : {len(nodes)}")
    log.info(f"      Links : {len(links)}")
    log.info(f"{'='*65}\n")


if __name__ == "__main__":
    run()
