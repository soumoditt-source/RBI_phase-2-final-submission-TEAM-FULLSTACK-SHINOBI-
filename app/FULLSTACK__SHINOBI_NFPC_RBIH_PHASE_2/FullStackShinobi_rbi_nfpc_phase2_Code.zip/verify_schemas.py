import polars as pl
from pathlib import Path

files = [
    'accounts.parquet', 
    'branch.parquet', 
    'customers.parquet', 
    'product_details.parquet', 
    'accounts-additional.parquet',
    'demographics.parquet'
]

print("--- SCHEMA VERIFICATION ---")
for f in files:
    if Path(f).exists():
        cols = pl.scan_parquet(f).columns
        print(f"{f}: {cols}")
    else:
        print(f"{f}: NOT FOUND")
