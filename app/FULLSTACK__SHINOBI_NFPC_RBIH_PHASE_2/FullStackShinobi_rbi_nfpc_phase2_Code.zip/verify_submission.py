import os
import sys
import pandas as pd
import json
from pathlib import Path
import time

ROOT = Path(__file__).parent
REQUIRED_COLUMNS = ["account_id", "is_mule", "suspicious_start", "suspicious_end"]
TEST_ACCOUNTS_EXPECTED = 64062
TRAIN_ACCOUNTS_EXPECTED = 96091
TOTAL_ACCOUNTS = 160153

def run_verification():
    print(f"\n=============================================")
    print(f" SUPREME 11/10 VERIFICATION & INTEGRITY TEST ")
    print(f"=============================================\n")
    
    # 1. Check Submission format and stats
    sub_path = ROOT / "submission.csv"
    if not sub_path.exists():
        print("❌ [FAIL] submission.csv is missing!")
        sys.exit(1)
        
    df = pd.read_csv(sub_path)
    print(f"📥 Loaded submission.csv (Rows: {len(df):,})")
    
    # Check Columns
    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_cols:
        print(f"❌ [FAIL] Missing required columns: {missing_cols}")
        sys.exit(1)
    print(f"✅ Schema Verified: {df.columns.tolist()}")
    
    # Check Math Output (Probabilities)
    if not (df['is_mule'].between(0.0, 1.0)).all():
        print("❌ [FAIL] Some 'is_mule' probabilities are out of 0.0 - 1.0 bounds.")
        sys.exit(1)
        
    high_count = len(df[df['is_mule'] > 0.5])
    print(f"✅ Probability Bounds Verified (0.0 to 1.0)")
    print(f"📊 High-Risk Accounts (>50% probability): {high_count:,}")
    
    # 2. Verify account volume matches 17.2GB set (64,062 test accounts)
    if len(df) == TEST_ACCOUNTS_EXPECTED:
        print(f"✅ Test Account Volume Verified ({TEST_ACCOUNTS_EXPECTED:,})")
    else:
        print(f"⚠️ [WARN] Expected {TEST_ACCOUNTS_EXPECTED} test accounts but got {len(df)}.")

    # 3. Check Caching & Visual Assets
    hft_path = ROOT / "results" / "hft_features.parquet"
    if hft_path.exists():
        hft_sz = hft_path.stat().st_size / 1024 / 1024
        print(f"✅ HFT Features Cache Built ({hft_sz:.1f} MB)")
    else:
        print(f"⚠️ [WARN] HFT Features missing. Visuals may not load.")

    money_path = ROOT / "results" / "money_chain.json"
    if money_path.exists():
        money_links = json.load(open(money_path)).get('links', [])
        print(f"✅ Money Network Built (Top Links: {len(money_links)})")
    
    print(f"\n=============================================")
    print(f" 🏆 VERIFICATION COMPLETE. FIU DASHBOARD READY.")
    print(f"=============================================\n")

if __name__ == "__main__":
    run_verification()
